# HELPER Hosting, AI and Storage — beta architecture

## Recommended private-beta architecture

### Web/API hosting
Run the existing FastAPI Docker image on a managed application host such as Render. Use one application instance during the SQLite beta to avoid concurrent-write issues.

### Database
Current tested application database: encrypted-field SQLite on a persistent encrypted disk.

This is acceptable for a small controlled beta on a single instance, but not the preferred long-term public architecture. Before scaling to multiple instances or a large public launch, migrate the relational data to managed PostgreSQL.

### Document/evidence storage
Use a private S3-compatible object bucket in the UK/EU region. HELPER encrypts each uploaded file before it is sent to object storage. Keep public access disabled, block bucket listing, use least-privilege service credentials and enable provider versioning/retention according to the backup policy.

### Encryption key
`HELPER_ENCRYPTION_KEY` must be a production secret stored in the hosting provider secret manager/environment, not in the repository or ZIP. Losing this key means losing access to encrypted case data.

### AI
Use the OpenAI Responses API from the server only. Never put the API key in browser JavaScript. HELPER sends a minimised grounded prompt and uses `store=false`. Live AI remains opt-in at user level.

Suggested beta model: a lower-cost current model suitable for general text, with strict grounding and fallbacks. Review OpenAI pricing and privacy controls before launch.

### Backups
- Database backup daily during beta.
- Encrypted uploaded evidence is independently retained in object storage according to configured versioning/backup rules.
- Keep backup encryption/access credentials separate from the primary application credentials where practicable.
- Test restoration before inviting users.

### Monitoring
Add uptime monitoring, error alerting and log redaction before public launch. Application logs must not contain decrypted complaint text or evidence.

## What HELPER can deploy once accounts are connected
With a connected hosting provider, the app service, environment variables, persistent disk/database and deploy process can be created. A real OpenAI API key and object-storage credentials still need to come from the owner of those accounts.
