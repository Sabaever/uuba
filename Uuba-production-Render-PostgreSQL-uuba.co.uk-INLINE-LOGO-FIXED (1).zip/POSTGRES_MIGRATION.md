# PostgreSQL migration notes

The production package uses PostgreSQL whenever `DATABASE_URL` is a PostgreSQL URL. SQLite remains available for local development only.

## Starting clean
For a new private beta, the safest option is usually to let Render create a clean PostgreSQL database and avoid migrating prototype/test users.

## Keeping existing SQLite records
Use `migrate_sqlite_to_postgres.py`. The migration copies primary keys and resets PostgreSQL sequences afterwards.

**Encryption warning:** encrypted columns are copied exactly as stored. The production `UUBA_ENCRYPTION_KEY` must be the same key that encrypted those records. If the key is lost or different, old encrypted data is not recoverable by the application.

## Backups
Render Postgres is the system of record for account/case metadata. `ops/backup_postgres.sh` provides a `pg_dump` helper for environments where the PostgreSQL client tools are available. Production database backup/restore should also be configured and tested through the Render database controls appropriate to the chosen plan.
