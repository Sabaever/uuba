# HELPER v7 checks

- Specialist Help section contains visible HELPER Core, Plus and Specialist Review pricing.
- Dedicated `/specialists` and `/specialists.html` routes added.
- Specialist directory slots exist for six major areas, with no invented firm names or fees.
- Partner fees remain explicitly partner-set.
- Existing AI Specialist Review workflow remains linked from the specialist page.
