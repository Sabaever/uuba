# HELPER Data Retention Schedule — private beta draft

| Data | Default beta retention | Rationale / action |
|---|---:|---|
| Active account | Until deletion/closure | Needed to provide service |
| Open case content | While case remains open | User-controlled case management |
| Closed/resolved case | User-selected; default 730 days | Allow later reference/appeal; delete when period expires |
| Uploaded evidence | Same as parent case | Delete with case/account; encrypted backup copies expire under backup policy |
| Ask HELPER messages | Same as account/case | Case continuity and audit of guidance given |
| Generated letters | Same as parent case | User case record |
| Sessions | 7 days by default | Security/access continuity |
| Rate-limit events | 24 hours | Abuse protection |
| Security audit log | 90 days by default | Incident/security investigation; minimise content |
| Backups | 30 days by default | Disaster recovery; encrypted and access-controlled |
| Marketing preference | Until withdrawn/account closure plus minimal suppression record if required | Respect communications choice |

## Rules
- Retention must be reviewed before public launch.
- Do not keep complaint data indefinitely “just in case”.
- Backup deletion may lag live deletion until the backup expires.
- Legal hold: where data must be preserved for a specific legal obligation or dispute, document the reason, scope and review date.
