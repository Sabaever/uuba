# HELPER vs Resolver — competitor review

Reviewed: 18 October 2026

## Executive conclusion

Resolver is not merely a letter-template website. Its public materials show a mature complaint-management proposition: issue categorisation, complaint drafting, evidence attachments, routing to organisations, correspondence records, timelines, reminders, escalation prompts, rights content and templates. HELPER should therefore **not** claim that case management, evidence storage, reminders, timelines or escalation prompts are unique.

HELPER's differentiation should instead be built around **case intelligence**: a maintained rights/rules layer plus case-aware AI that helps the user understand a reply, identify what remains unanswered, see evidence gaps, understand the verified trigger point, generate the next case-specific document and maintain a single visible next step.

## What Resolver already does well

1. **One complaint workspace and process.** Resolver describes one place and one process for raising and resolving complaints.
2. **Issue/service routing.** Users choose service and issue type so the complaint can be routed appropriately.
3. **Structured complaint drafting.** Resolver prompts users to explain what happened and the outcome sought.
4. **Evidence attachments.** Supporting documents and earlier correspondence can be attached/kept with the complaint.
5. **Communication management.** Resolver can keep a record of communications and a case timeline.
6. **Reminders and escalation prompts.** Public guidance says the system reminds users when to chase or escalate.
7. **Large company network.** Resolver publicly reports thousands of responding companies.
8. **Rights/guidance library.** Resolver publicly reports hundreds of articles/guides and continues publishing current consumer-rights content.
9. **Templates.** Resolver provides complaint letter templates even where a company is not directly contactable through Resolver.
10. **Accessibility value.** Resolver highlights reminders and reduced administrative burden for users who struggle with memory, stress or cognitive load.

## What HELPER should NOT claim as unique

- "all your evidence in one place"
- "a complaint timeline"
- "complaint reminders"
- "know when to escalate"
- "consumer-rights guidance"
- "complaint letter templates"
- "send a complaint to the right organisation"

These can remain features, but should be presented as expected foundations rather than the USP.

## HELPER's strongest USP

### 1. Verified knowledge layer + AI explanation
The generative model is not the legal/rules authority. HELPER's maintained knowledge base supplies verified rights, trigger points and escalation routes; AI explains and applies that material to the user's saved case.

### 2. Analyse the organisation's reply
A user should be able to paste/select a response and get a structured result:
- what the organisation actually answered;
- what it did not answer;
- what assertion needs evidence;
- whether the reply changes the route;
- the next sensible response.

### 3. One visible next step
Every open case should have three states visible at a glance:
- **Do now**
- **Waiting for**
- **Escalate when**

This is a stronger consumer promise than a generic timeline.

### 4. Evidence intelligence, not only evidence storage
HELPER should identify likely missing evidence based on the category and stage, maintain a chronology, and build an evidence index for escalation.

### 5. Multi-route recovery map
A complaint may have parallel routes: retailer/provider complaint, card-provider remedy, legal-expenses insurance, trade body, ADR, ombudsman, regulator, tribunal or court. HELPER should surface the relevant alternatives without implying that every route applies.

### 6. Case-generated escalation pack
Create a compact export containing chronology, key facts, evidence index, correspondence summary, desired outcome and relevant verified route information. This reduces the need to reconstruct the story for each new body.

### 7. Privacy-controlled AI
Live AI is optional. Uploaded documents are not automatically sent to the AI provider. The user should deliberately choose the case/reply material that is analysed.

### 8. Honest service boundary
HELPER should repeatedly state that it provides consumer information, organisation and AI-assisted guidance; it is not a law firm, does not represent users and cannot guarantee outcomes.

## Recommended public positioning

**HELPER — Your consumer case companion.**

**One problem. One case. One clear next step.**

HELPER brings your complaint, evidence, rights, replies and escalation route together. It helps you understand what matters, what has been answered, what is still missing and what to do next.

## Product changes recommended from the Resolver benchmark

Priority 1:
- prominent next-step panel on every case;
- response analyser;
- verified-source labels beside trigger points;
- evidence-gap checklist;
- case pack export.

Priority 2:
- organisation complaint-route directory;
- stage-aware reminders;
- accessibility controls and low-cognitive-load mode;
- route-specific document packs.

Priority 3:
- opt-in business response channel only if it does not compromise independence;
- aggregate anonymised complaint insights with a clear privacy boundary.

## Sources reviewed

- Resolver Guide to Making a Complaint: https://news.resolver.co.uk/resolver-guides/make-a-complaint/
- Resolver / Complainer about statistics and guidance library: https://complainer.test.resolver.co.uk/
- Resolver consumer rights archive: https://news.resolver.co.uk/category/consumer-rights/
- Resolver accessibility article: https://news.resolver.co.uk/all-things-accessibility/
- Resolver DPD complaints article (organisation unavailable through Resolver but case/evidence tools remain useful): https://news.resolver.co.uk/common-dpd-complaints-and-how-to-handle-them/
- Resolver ChatGPT complaints article: https://news.resolver.co.uk/using-chatgpt-to-complain/
- Resolver bank scam article (records, deadlines, escalation): https://news.resolver.co.uk/the-approve-payment-bank-scam-you-need-to-know-about/
- Resolver telecom ADR update: https://news.resolver.co.uk/broadband-and-mobile-complaints-can-go-to-the-ombudsman-faster-from-april-2026/

This document is product/competitor research, not legal advice and not a formal freedom-to-operate opinion.


## 2026-10-18 refinement: decision support and business-model distinction

Resolver is a meaningful benchmark because it already provides complaint routing, evidence storage, timelines, reminders and escalation support. Its own public material also states that insights from consumer complaint cases have been used to develop SaaS products for organisations to improve complaint management and customer experience. That is a legitimate business model, but HELPER should be deliberately explicit about its own consumer-first governance: commercial partnerships, sponsorship or business-side services must not alter consumer guidance, ranking, escalation logic or case outcomes.

The strongest HELPER differentiation is therefore not "case management". It is **case-aware decision support**: analysing what a response actually resolves, identifying unanswered points and missing evidence, mapping the facts to verified rights/policy/redress rules, showing the next available route, and recognising when a case has become sufficiently complex, high-value or procedurally advanced that independent specialist advice is appropriate.

### New-build example
A serious defects case may move through developer customer care, a formal complaint, warranty-provider involvement, an ombudsman/redress route and eventually specialist legal advice. HELPER should not simply move the user along a fixed escalation ladder. It should ask what the developer/warranty provider has accepted, what remains disputed, whether an expert report exists, whether the proposed scope of works answers the report, whether delay is causing continuing loss, whether the relevant trigger has actually been reached, and whether litigation would be proportionate.

This is the product thesis: **one problem, one case, one clear next decision — not merely one more complaint form.**
