"""Generate Uúba deployment secrets locally. Do not commit the output."""
from cryptography.fernet import Fernet
import secrets
print("UUBA_ENCRYPTION_KEY=" + Fernet.generate_key().decode())
print("UUBA_ADMIN_TOKEN=" + secrets.token_urlsafe(48))
print("BETA_ACCESS_CODE=" + secrets.token_urlsafe(12))
