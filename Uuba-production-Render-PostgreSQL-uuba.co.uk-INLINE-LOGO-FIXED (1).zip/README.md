# Uúba production deployment package

For Render/PostgreSQL/uuba.co.uk deployment, start with **PRODUCTION_DEPLOY_RENDER.md** and **GO_LIVE_CHECKLIST.md**. The prototype README content follows below for reference.

---

# HELPER production-style prototype

This build is a deployable application architecture, but **it is not a hosted production service until you deploy it and configure external services/secrets**.

## What is implemented

- Argon2 password hashing and authenticated user accounts.
- HttpOnly session cookies, per-session CSRF tokens, session expiry and logout.
- Per-user case isolation.
- Field-level authenticated encryption for names, case text, complaint references and messages.
- Encrypted document uploads with size/type limits, per-user access controls, download and deletion. Uploads can use encrypted local storage or optional managed S3 object storage via `S3_BUCKET`.
- Ask HELPER live-AI integration using the OpenAI **Responses API** when `OPENAI_API_KEY` is configured.
- A rules-engine fallback when no AI key is configured or the AI provider is unavailable.
- The AI is grounded with the selected case plus `knowledge.json`; the prompt tells it not to invent legal rights/deadlines/regulators.
- Rate limiting, security headers, audit events.
- GDPR-oriented data export, live-account deletion and configurable retention preference.
- Backup script with checksums and configurable backup retention.

## What “AI” operates on

Ask HELPER receives:
1. the user's question;
2. the selected case record;
3. the relevant verified HELPER guidance from `knowledge.json`;
4. a system instruction that forbids inventing legal rights, deadlines or regulators.

If `OPENAI_API_KEY` is absent, `/api/health` reports `rules-fallback` and questions are answered only by the local rules engine. The UI/API should never describe that state as live AI.

## Local setup

1. Install Python 3.11+.
2. Copy `.env.example` values into your environment. For local testing `COOKIE_SECURE=0` is needed because localhost is HTTP.
3. Generate a Fernet key:
   `python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"`
4. Put that value in `HELPER_ENCRYPTION_KEY`.
5. Add `OPENAI_API_KEY` if you want live AI.
6. Run `start-helper.bat` on Windows or `./start-helper.sh` on macOS/Linux.

## Production deployment requirements

The included encrypted SQLite/local-file implementation is appropriate for a single-server prototype. A real public service should deploy behind HTTPS and replace single-host persistence with managed services, for example:
- managed PostgreSQL with encrypted-at-rest disks, point-in-time recovery and restricted network access (not provisioned by this package; the tested persistence mode is SQLite);
- encrypted object storage for uploads, versioning/lifecycle rules and malware scanning;
- a managed secrets service for encryption/API keys;
- a distributed rate limiter such as Redis if running multiple instances;
- central monitoring and alerting;
- scheduled tested backups and restore drills.

Those cloud resources cannot be provisioned from this chat because no cloud account/credentials were supplied. The application boundaries are designed so those services can replace the local implementations.

## GDPR / privacy controls

Routes:
- `GET /api/privacy/export` — downloadable ZIP of profile, cases, messages and decrypted user documents.
- `PUT /api/privacy/retention` — user retention preference.
- `DELETE /api/privacy/account` — deletes live account data and uploaded files.

The product owner still needs a documented lawful-basis assessment, privacy notice, processor contracts, retention schedule, DPIA where appropriate, incident response process and a policy for backup deletion. The code alone does not create GDPR compliance.

## Backups

Run `python backup.py`. It uses SQLite's backup API, copies already-encrypted uploads, creates SHA-256 checksums and prunes backups older than `BACKUP_RETENTION_DAYS` (default 30).

## Important safety boundary

HELPER is consumer guidance, not legal advice. The verified rules store and source review process are part of the product; the AI should explain those rules and case facts rather than independently invent legal conclusions.


See `SECURITY_AND_PRIVACY.md` and `PRODUCTION_CHECKLIST.md` before any public launch.

## October 2026 content additions
- Employment-law guidance, including grievances, disciplinary/appeal steps, ACAS Early Conciliation and Employment Tribunal trigger points.
- Employment case support in Ask HELPER's verified-rules knowledge base.
- Legal-expenses insurance prompts across relevant consumer and employment journeys.
- New Homes Ombudsman 2025/26 complaint statistics and clearer context around the growth in NHOS coverage/awareness.
- More photographic visual content using externally hosted Unsplash images. The production Content Security Policy explicitly permits `https://images.unsplash.com`; for a self-contained production deployment, download/licence approved imagery and serve it from your own CDN/assets instead.

## v4 — case-generated documents

The template library remains available as a reference, but signed-in users can now use **Create my letter** to generate documents from a saved case.

A case can store optional identifiers used in documents, including:
- account/order/booking/employee number;
- product/service/property/job description;
- correspondence/property address;
- amount paid or disputed;
- payment method;
- purchase/completion/contract date;
- warranty/policy provider and number;
- new-build plot and development;
- employment job title;
- previous contact/key dates;
- requested response date.

Generated documents are stored per-user in the database with encrypted title/body fields, can be reviewed, copied, printed/saved as PDF from the browser, downloaded as text, deleted, and are included in the user's GDPR export. No generated document is sent automatically.

Available document types are category-specific. New-build cases include snagging schedule cover letters, formal developer complaints, overdue-stage chasers, warranty/NHBC resolution requests, NHOS summaries and urgent serious-defect notifications. Employment includes formal grievances, appeals, ACAS summaries and pay complaints.

---

# Controlled private beta deployment (October 2026)

## Recommended beta stack

- **App/API:** Render Docker web service (or equivalent managed container host)
- **Database for beta:** encrypted-field SQLite on one persistent disk / one app instance
- **Evidence/documents:** private S3-compatible object storage in a UK/EU region, with HELPER encrypting files before upload
- **AI:** OpenAI Responses API, server-side only, `store=false`, user opt-in
- **TLS/domain:** managed HTTPS on your chosen host and custom domain

This is intentionally a **private-beta** architecture. Before a large public launch or multi-instance scaling, move relational data from SQLite to managed PostgreSQL.

## Deployment files

- `render.yaml` — Render Blueprint for a single beta web service + persistent disk
- `.env.example` — all required/optional secrets
- `HOSTING_AI_STORAGE.md` — architecture and storage decisions
- `PRIVATE_BETA_PLAN.md` — controlled testing plan
- `DPIA_DRAFT.md` — data-protection impact assessment working draft
- `RETENTION_SCHEDULE.md` — retention schedule
- `PROCESSING_REGISTER.md` — processing record draft
- `INCIDENT_RESPONSE.md` — incident plan
- `legal/` — user-facing Privacy, Terms, AI Transparency, Cookies and Beta notices

## AI activation

Set `OPENAI_API_KEY` on the server and choose `OPENAI_MODEL`. Never put the API key in `index.html` or client-side JavaScript. Live AI is still user-opt-in from the HELPER privacy controls. When live AI is not enabled or the key is absent, Ask HELPER uses the verified-rules fallback.

## Private beta access

Set `BETA_ACCESS_CODE`. New registrations then require that invitation code plus explicit acceptance of HELPER's Terms and Privacy Notice.

## Storage

If `S3_BUCKET` is configured, evidence is encrypted by HELPER before it is uploaded. If no bucket is configured, encrypted evidence is stored locally under `data/uploads`. Local evidence storage is suitable only for development or a carefully controlled single-server beta with backup/restore testing.

## Before inviting real users

1. Replace all bracketed company/contact placeholders in `legal/`.
2. Have a UK technology/data-protection/consumer-law solicitor review the Terms, Privacy Notice, AI wording, claims-management boundaries and sponsorship/referral model.
3. Complete ICO fee/self-assessment and DPIA sign-off.
4. Arrange appropriate PI/E&O and cyber insurance.
5. Configure real hosting, HTTPS, object storage and production secrets.
6. Configure OpenAI API project/key and review its data controls.
7. Perform an external security review/penetration test.
8. Run and restore a real backup before beta invitations.


## 18 October 2026 — Resolver benchmark refresh
The front end has been repositioned around HELPER's differentiator: verified consumer-rights knowledge plus case-aware AI and a single visible next step. Case management, evidence storage, timelines and reminders are treated as baseline features because established complaint platforms already provide them. See `RESOLVER_COMPETITOR_REVIEW.md` for the competitor teardown and product priorities. The AI system prompt and transparency notice have also been tightened to make clear that HELPER is not a law firm, does not guarantee outcomes and must use verified HELPER guidance for rights/deadlines/escalation routes.

## Response Analyser

The current build includes a category-aware Response Analyser. A signed-in user selects a saved case and pastes an organisation reply. HELPER returns separate sections for answered points, unanswered/unclear points, evidence to check, verified trigger/timing guidance, and the recommended next step. Live AI analysis is optional and uses only a minimised case context plus verified HELPER category guidance; rules-only mode remains available as a transparent checklist fallback.

All ten categories now carry a decision-support checklist and case-review questions so the analyser uses category-specific logic rather than a generic complaint summary.


## Commercial model update
See `COMMERCIAL_MODEL.md` and `/legal/partner-transparency.html`. The current working model keeps core consumer guidance free, tests optional premium analysis/case-pack tools, and allows only clearly labelled commercial partnerships that cannot influence HELPER guidance. Paid legal referral models remain subject to UK regulatory review before activation.


## Consumer Voices

This build adds a moderated Consumer Voices community area at `/consumer-voices` and a signed-in submission page at `/consumer-voices/share`. New posts are **pending by default** and do not appear publicly until approved using the admin moderation API. Private HELPER case data is not copied into community posts. Users can withdraw their own submissions and signed-in users can report approved posts.

Moderation endpoints use the existing `HELPER_ADMIN_TOKEN` bearer token:
- `GET /api/admin/community/pending`
- `POST /api/admin/community/posts/{post_id}/moderate` with `{"action":"approve"}` or `{"action":"reject"}`

Before public launch, the moderation workflow and community clauses in Terms/Privacy should receive legal review.

### Consumer Voices moderation

Consumer Voices is visible from the main site and has a dedicated moderator UI at `/admin/community`. Set `HELPER_ADMIN_TOKEN` in the server environment, open the moderator page, and enter that token to review submissions and reports. The token is kept in browser session storage only and is never embedded in the HTML.


## v6 — Specialist Review

The Specialist Help workspace now includes an interactive AI-first Specialist Review. A signed-in user selects a saved case and can add the latest reply/context. HELPER produces a first-pass structured review and a copyable Specialist Review Pack. If live AI is not configured or the user has not opted in, the same flow transparently falls back to rules-based preparation. Uploaded document contents are not automatically analysed; only their saved filenames/metadata are included in the evidence index.

## UÚBA colour + legal pass — 20 October 2026

This release is a superset of HELPER v7. See `HELPER_V7_PRESERVATION_AUDIT.md` for preservation checks.

### Colour experiments
Open `colour-lab.html` to compare four palettes:
- Aurora (current recommended/default): navy + teal + sky
- Stellar blue
- Guidance green
- Warm action

The public homepage keeps the full HELPER v7 structure and uses Aurora by default.

### Legal/compliance additions
New pages:
- `legal/accessibility.html`
- `legal/complaints.html`
- `legal/company-information.html`

Existing privacy, terms and cookie drafts were supplemented rather than replaced. See `LEGAL_COMPLIANCE_AUDIT.md` for launch items that still require real company details and professional review.
