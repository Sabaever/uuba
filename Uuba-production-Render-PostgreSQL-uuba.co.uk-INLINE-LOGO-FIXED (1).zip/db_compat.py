from __future__ import annotations

import re
import sqlite3
from pathlib import Path
from typing import Any, Iterable

POSTGRES_TABLES_WITH_IDS = {
    "users", "sessions", "cases", "messages", "documents", "generated_letters",
    "audit_log", "community_posts", "community_reports", "rate_events",
}

SQLITE_SCHEMA = r'''
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  display_name_enc TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  last_login_at TEXT,
  deleted_at TEXT,
  retention_days INTEGER NOT NULL DEFAULT 730,
  marketing_consent INTEGER NOT NULL DEFAULT 0,
  ai_enabled INTEGER NOT NULL DEFAULT 0,
  terms_accepted_at TEXT,
  terms_version TEXT,
  privacy_version TEXT
);
CREATE TABLE IF NOT EXISTS sessions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  token_hash TEXT NOT NULL UNIQUE,
  csrf_token TEXT NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  ip_hash TEXT,
  user_agent_hash TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS cases(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  organisation_enc TEXT NOT NULL,
  complaint_ref_enc TEXT,
  category TEXT NOT NULL,
  subcategory TEXT,
  problem_date TEXT,
  facts_enc TEXT NOT NULL,
  desired_outcome_enc TEXT,
  case_meta_enc TEXT,
  status TEXT NOT NULL DEFAULT 'Open',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  closed_at TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS messages(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  case_id INTEGER,
  role TEXT NOT NULL,
  content_enc TEXT NOT NULL,
  ai_mode TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(case_id) REFERENCES cases(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS documents(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  case_id INTEGER NOT NULL,
  original_name_enc TEXT NOT NULL,
  stored_key TEXT NOT NULL UNIQUE,
  content_type TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  sha256 TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(case_id) REFERENCES cases(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS generated_letters(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  case_id INTEGER NOT NULL,
  letter_type TEXT NOT NULL,
  title_enc TEXT NOT NULL,
  body_enc TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(case_id) REFERENCES cases(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_letters_user_case ON generated_letters(user_id, case_id);
CREATE TABLE IF NOT EXISTS audit_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  event TEXT NOT NULL,
  meta TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS community_posts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  alias_enc TEXT NOT NULL,
  category TEXT NOT NULL,
  organisation_enc TEXT,
  title_enc TEXT NOT NULL,
  story_enc TEXT NOT NULL,
  tried_enc TEXT,
  helped_enc TEXT,
  outcome_enc TEXT,
  case_status TEXT NOT NULL DEFAULT 'Ongoing',
  moderation_status TEXT NOT NULL DEFAULT 'pending',
  moderation_note_enc TEXT,
  consent_publication INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  published_at TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS community_reports(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER NOT NULL,
  reporter_user_id INTEGER NOT NULL,
  reason TEXT NOT NULL,
  details_enc TEXT,
  created_at TEXT NOT NULL,
  resolved_at TEXT,
  FOREIGN KEY(post_id) REFERENCES community_posts(id) ON DELETE CASCADE,
  FOREIGN KEY(reporter_user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_community_public ON community_posts(moderation_status,category,created_at);
CREATE INDEX IF NOT EXISTS idx_community_user ON community_posts(user_id,created_at);
CREATE INDEX IF NOT EXISTS idx_community_reports_post ON community_reports(post_id,created_at);
CREATE TABLE IF NOT EXISTS rate_events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  key_hash TEXT NOT NULL,
  created_ts INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cases_user ON cases(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_user_case ON messages(user_id, case_id);
CREATE INDEX IF NOT EXISTS idx_docs_user_case ON documents(user_id, case_id);
CREATE INDEX IF NOT EXISTS idx_rate_key_ts ON rate_events(key_hash, created_ts);
'''

POSTGRES_SCHEMA = r'''
CREATE TABLE IF NOT EXISTS users(
  id BIGSERIAL PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  display_name_enc TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  last_login_at TEXT,
  deleted_at TEXT,
  retention_days INTEGER NOT NULL DEFAULT 730,
  marketing_consent INTEGER NOT NULL DEFAULT 0,
  ai_enabled INTEGER NOT NULL DEFAULT 0,
  terms_accepted_at TEXT,
  terms_version TEXT,
  privacy_version TEXT
);
CREATE TABLE IF NOT EXISTS sessions(
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  csrf_token TEXT NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  ip_hash TEXT,
  user_agent_hash TEXT
);
CREATE TABLE IF NOT EXISTS cases(
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  organisation_enc TEXT NOT NULL,
  complaint_ref_enc TEXT,
  category TEXT NOT NULL,
  subcategory TEXT,
  problem_date TEXT,
  facts_enc TEXT NOT NULL,
  desired_outcome_enc TEXT,
  case_meta_enc TEXT,
  status TEXT NOT NULL DEFAULT 'Open',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  closed_at TEXT
);
CREATE TABLE IF NOT EXISTS messages(
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  case_id BIGINT REFERENCES cases(id) ON DELETE CASCADE,
  role TEXT NOT NULL,
  content_enc TEXT NOT NULL,
  ai_mode TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS documents(
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  case_id BIGINT NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  original_name_enc TEXT NOT NULL,
  stored_key TEXT NOT NULL UNIQUE,
  content_type TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  sha256 TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS generated_letters(
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  case_id BIGINT NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  letter_type TEXT NOT NULL,
  title_enc TEXT NOT NULL,
  body_enc TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_log(
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT,
  event TEXT NOT NULL,
  meta TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS community_posts(
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  alias_enc TEXT NOT NULL,
  category TEXT NOT NULL,
  organisation_enc TEXT,
  title_enc TEXT NOT NULL,
  story_enc TEXT NOT NULL,
  tried_enc TEXT,
  helped_enc TEXT,
  outcome_enc TEXT,
  case_status TEXT NOT NULL DEFAULT 'Ongoing',
  moderation_status TEXT NOT NULL DEFAULT 'pending',
  moderation_note_enc TEXT,
  consent_publication INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  published_at TEXT
);
CREATE TABLE IF NOT EXISTS community_reports(
  id BIGSERIAL PRIMARY KEY,
  post_id BIGINT NOT NULL REFERENCES community_posts(id) ON DELETE CASCADE,
  reporter_user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reason TEXT NOT NULL,
  details_enc TEXT,
  created_at TEXT NOT NULL,
  resolved_at TEXT
);
CREATE TABLE IF NOT EXISTS rate_events(
  id BIGSERIAL PRIMARY KEY,
  key_hash TEXT NOT NULL,
  created_ts BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_letters_user_case ON generated_letters(user_id, case_id);
CREATE INDEX IF NOT EXISTS idx_community_public ON community_posts(moderation_status,category,created_at);
CREATE INDEX IF NOT EXISTS idx_community_user ON community_posts(user_id,created_at);
CREATE INDEX IF NOT EXISTS idx_community_reports_post ON community_reports(post_id,created_at);
CREATE INDEX IF NOT EXISTS idx_cases_user ON cases(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_user_case ON messages(user_id, case_id);
CREATE INDEX IF NOT EXISTS idx_docs_user_case ON documents(user_id, case_id);
CREATE INDEX IF NOT EXISTS idx_rate_key_ts ON rate_events(key_hash, created_ts);
ALTER TABLE users ADD COLUMN IF NOT EXISTS ai_enabled INTEGER NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS terms_accepted_at TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS terms_version TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS privacy_version TEXT;
ALTER TABLE cases ADD COLUMN IF NOT EXISTS case_meta_enc TEXT;
'''

class RowCompat(dict):
    def __getitem__(self, key):
        if isinstance(key, int):
            return list(self.values())[key]
        return super().__getitem__(key)

class PgCursorCompat:
    def __init__(self, cursor, *, lastrowid=None, prefetched=None):
        self._cursor = cursor
        self.lastrowid = lastrowid
        self._prefetched = prefetched
        self.rowcount = cursor.rowcount

    @staticmethod
    def _wrap(row):
        if row is None:
            return None
        if isinstance(row, dict):
            return RowCompat(row)
        return row

    def fetchone(self):
        if self._prefetched is not None:
            row = self._prefetched
            self._prefetched = None
            return self._wrap(row)
        return self._wrap(self._cursor.fetchone())

    def fetchall(self):
        rows = []
        if self._prefetched is not None:
            rows.append(self._wrap(self._prefetched))
            self._prefetched = None
        rows.extend(self._wrap(r) for r in self._cursor.fetchall())
        return rows

class PgConnectionCompat:
    def __init__(self, database_url: str):
        import psycopg
        from psycopg.rows import dict_row
        self._con = psycopg.connect(database_url, row_factory=dict_row)

    @staticmethod
    def _translate(sql: str) -> str:
        return sql.replace("?", "%s")

    def execute(self, sql: str, params: Iterable[Any] = ()):
        sql_pg = self._translate(sql)
        cur = self._con.cursor()
        insert_match = re.match(r"\s*INSERT\s+INTO\s+([a-zA-Z_][a-zA-Z0-9_]*)", sql_pg, flags=re.I)
        if insert_match and " RETURNING " not in sql_pg.upper() and insert_match.group(1).lower() in POSTGRES_TABLES_WITH_IDS:
            sql_pg = sql_pg.rstrip().rstrip(";") + " RETURNING id"
            cur.execute(sql_pg, tuple(params))
            row = cur.fetchone()
            lastrowid = row["id"] if row else None
            return PgCursorCompat(cur, lastrowid=lastrowid)
        cur.execute(sql_pg, tuple(params))
        return PgCursorCompat(cur)

    def commit(self):
        self._con.commit()

    def rollback(self):
        self._con.rollback()

    def close(self):
        self._con.close()


def is_postgres(database_url: str | None) -> bool:
    u = (database_url or "").lower()
    return u.startswith("postgresql://") or u.startswith("postgres://")


def connect_db(database_url: str | None, sqlite_path: Path):
    if is_postgres(database_url):
        return PgConnectionCompat(database_url or "")
    con = sqlite3.connect(sqlite_path, timeout=15)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA journal_mode=WAL")
    return con


def init_database(database_url: str | None, sqlite_path: Path) -> None:
    if is_postgres(database_url):
        con = PgConnectionCompat(database_url or "")
        try:
            for statement in [s.strip() for s in POSTGRES_SCHEMA.split(";") if s.strip()]:
                con.execute(statement)
            con.commit()
        finally:
            con.close()
        return

    con = connect_db(database_url, sqlite_path)
    try:
        con.executescript(SQLITE_SCHEMA)
        cols = {r[1] for r in con.execute("PRAGMA table_info(users)").fetchall()}
        if "ai_enabled" not in cols:
            con.execute("ALTER TABLE users ADD COLUMN ai_enabled INTEGER NOT NULL DEFAULT 0")
        if "terms_accepted_at" not in cols:
            con.execute("ALTER TABLE users ADD COLUMN terms_accepted_at TEXT")
        if "terms_version" not in cols:
            con.execute("ALTER TABLE users ADD COLUMN terms_version TEXT")
        if "privacy_version" not in cols:
            con.execute("ALTER TABLE users ADD COLUMN privacy_version TEXT")
        case_cols = {r[1] for r in con.execute("PRAGMA table_info(cases)").fetchall()}
        if "case_meta_enc" not in case_cols:
            con.execute("ALTER TABLE cases ADD COLUMN case_meta_enc TEXT")
        con.commit()
    finally:
        con.close()
