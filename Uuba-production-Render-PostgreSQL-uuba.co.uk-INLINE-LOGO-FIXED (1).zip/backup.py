#!/usr/bin/env python3
import hashlib, json, os, shutil, sqlite3, tarfile
from datetime import datetime, timezone, timedelta
from pathlib import Path
ROOT=Path(__file__).resolve().parent; DATA=ROOT/'data'; DB=DATA/'helper.db'; UP=DATA/'uploads'; BACK=DATA/'backups'; BACK.mkdir(parents=True,exist_ok=True)
keep=int(os.getenv('BACKUP_RETENTION_DAYS','30'))
ts=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'); work=BACK/f'.work-{ts}'; work.mkdir()
# SQLite online-safe backup
src=sqlite3.connect(DB); dst=sqlite3.connect(work/'helper.db'); src.backup(dst); dst.close(); src.close()
if UP.exists(): shutil.copytree(UP,work/'uploads')
manifest=[]
for p in work.rglob('*'):
    if p.is_file(): manifest.append({'file':str(p.relative_to(work)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(work/'manifest.json').write_text(json.dumps({'created_at':ts,'files':manifest},indent=2))
out=BACK/f'helper-backup-{ts}.tar.gz'
with tarfile.open(out,'w:gz') as tar: tar.add(work,arcname='helper-backup')
shutil.rmtree(work)
cut=datetime.now(timezone.utc)-timedelta(days=keep)
for p in BACK.glob('helper-backup-*.tar.gz'):
    if datetime.fromtimestamp(p.stat().st_mtime,timezone.utc)<cut: p.unlink()
print(out)
