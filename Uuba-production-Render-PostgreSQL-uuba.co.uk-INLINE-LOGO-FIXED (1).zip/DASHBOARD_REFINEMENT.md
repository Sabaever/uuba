# HELPER dashboard refinement — Option B locked

Working visual direction: navy + teal/sky.

## Added
- Five-part workspace rail: My Case, Ask HELPER, Analyse Reply, Guidance, Specialist Help.
- Stronger hierarchy and colour-coding around the core consumer journey.
- Active workspace highlighting while scrolling.
- Dedicated Specialist Help section focused on the point where self-help may no longer be enough.
- Specialist Review Pack explanation and independence wording.
- Main navigation link to Specialist Help.

## Design intent
Navy = trust / case ownership.
Blue = case-aware assistance.
Teal = analysis / next-step intelligence.
Sky = verified guidance.
Deep teal = specialist escalation.

The product should feel like an interactive case workspace rather than a long information website.
