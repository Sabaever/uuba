# HELPER commercial model — working plan

## Principle
HELPER should remain useful without payment. Revenue must not influence consumer guidance, response analysis, rankings, escalation routes or specialist-help prompts.

## Recommended income streams

### 1. HELPER Plus — consumer premium
Use a modest subscription or one-case pass for advanced features rather than charging for basic rights information. Potential premium features: higher AI usage, deeper Response Analyser, multi-case support, automated chronology, advanced evidence gap analysis, exports and deadline monitoring.

### 2. Specialist Review Pack — one-off consumer purchase
A tangible paid output for complex cases: chronology, evidence index, accepted/disputed/unanswered points, key correspondence summary, losses/issues to document and questions for a solicitor/surveyor/other expert. It must not provide a legal merits opinion or promise success.

### 3. Fixed-fee professional partnerships
Solicitors, surveyors or other specialists may pay a fixed subscription/sponsorship/listing fee for clearly labelled presence. Prefer fixed commercial fees over per-claim commissions in the early model. No partner may pay to alter guidance or ranking. A free first consultation can be advertised if genuinely offered by the firm.

### 4. Verified professional directory
Professionals can pay for enhanced profiles after objective verification criteria are met. Search/ranking rules should be published and must not be secretly pay-to-win. Sponsored positions must be labelled.

### 5. White-label / organisation licensing
Later, licence HELPER workflows to unions, charities, professional bodies, membership organisations, universities, advice organisations and employee-support schemes. Avoid making organisations that are frequent complaint targets the core funding source for complainant-facing guidance unless governance and separation are exceptionally strong.

### 6. Knowledge/API licensing
Licence maintained consumer-rights decision trees, trigger logic or workflow APIs to trusted consumer-support organisations. Keep the underlying verified rules separately governed and auditable.

### 7. Aggregate insight reports — later only
Potential future reports on complaint themes, resolution friction and evidence gaps using properly anonymised/aggregated data. Do not sell identifiable case data. Do not make this an early revenue dependency. Complete privacy, DPIA and legal review first.

## Models to avoid or treat cautiously
- Selling identifiable complaint data.
- Selling consumer contact details without an explicit user action.
- Hidden paid rankings.
- Commission-driven advice or steering.
- Per-lead legal referrals before regulatory advice on FCA claims-management and SRA rules.
- Taking a percentage of compensation/recovery unless the business has been specifically structured and authorised for any applicable regulated activity.

## Suggested beta tests
1. Free Core.
2. Test Plus as either a low monthly fee or a one-case pass.
3. Test a one-off Specialist Review Pack because it has a clear, concrete value at the point a case becomes complex.
4. Recruit a small number of founding professional partners on fixed-fee or initially free pilot terms in return for reviewing workflows and offering genuine first consultations where appropriate.
5. Do not switch on paid legal referrals until a UK regulatory solicitor has reviewed the actual customer journey, contracts and remuneration structure.


## Provisional private-beta consumer pricing (v7)

- HELPER Core: **Free**
- UÚBA Plus: **£6.99/month or £59/year**, cancel any time
- AI Specialist Review + Pack: **£24.99 one-off**
- Professional consultation/advice: **set by the independent specialist**, shown transparently when partner details are added. A free initial consultation may be displayed only where genuinely offered.

These are test prices for the private beta, not permanent launch commitments. Review conversion, AI/API cost, moderation/support burden, insurance/compliance overhead and perceived user value before final launch pricing.


## Refund and complaint ownership
- Private beta owner: UÚBA operator/admin.
- Public launch: assign a named Support & Complaints Lead and absence cover.
- Check support/refund queue each business day.
- Apply statutory rights before discretionary policy.
- Track complaint themes and report recurring issues into product/compliance review.
