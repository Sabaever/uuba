# HELPER launch fields that still require owner/legal input

- Legal company name
- Companies House number
- Registered office
- Consumer/support email
- Privacy/DPO contact email
- Final domain
- ICO registration/fee assessment result and registration number if applicable
- Insurance provider/policy details
- Hosting provider and hosting region
- Object-storage provider and region
- Database provider (for post-beta Postgres migration)
- OpenAI API organisation/project details
- List of processors/subprocessors
- International transfer mechanism/assessment where required
- Solicitor review/sign-off date
- Regulated claims-management legal review
- Sponsorship/referral policy
- Complaints process for HELPER itself
