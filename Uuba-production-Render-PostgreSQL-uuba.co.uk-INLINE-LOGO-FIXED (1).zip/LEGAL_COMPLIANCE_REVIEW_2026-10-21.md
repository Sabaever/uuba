# UÚBA legal/compliance review — 21 October 2026

## Status
The legal pages are now populated and the broken local-file legal links have been corrected.

This is a structured compliance review against current public UK sources. It is **not** a formal solicitor's opinion and does not replace legal advice.

## Checks completed
- UK GDPR / Data Protection Act transparency: privacy purposes, categories, lawful bases, recipients/processors, international transfers, retention, rights and ICO complaints are covered.
- PECR cookies/device storage: current necessary session cookie documented; non-essential analytics/advertising should remain off until valid consent is implemented.
- Consumer Rights Act 2015: terms do not attempt to exclude mandatory consumer rights; service/digital-content quality obligations are acknowledged.
- Distance selling / digital content: checkout must provide required pre-contract information and durable-medium confirmation; cooling-off treatment must match the exact paid product.
- 2026 subscription-contract rules: recurring plans need required pre-contract information, reminder/cooling-off notices where applicable, and straightforward online cancellation.
- Companies trading disclosures: company name, registration jurisdiction, number and registered office must be filled in after incorporation and displayed on the website.
- Accessibility: WCAG 2.2 AA adopted as product target; full manual audit still required before claiming conformity.
- Claims-management perimeter: financial-services, housing-disrepair, employment and other regulated claim/referral flows require FCA perimeter review before paid lead/referral activity.
- Solicitor referrals: financial interests/referral or fee-sharing arrangements must be transparent; solicitors have separate SRA duties.
- AI transparency: optional live AI, minimised prompts, no automatic evidence-file analysis, limits and OpenAI API data-handling position are described.

## Items that cannot be finalised yet
1. Legal company name, company number, registered office and registration jurisdiction.
2. Privacy/support/accessibility contact addresses.
3. Final production hosting/database/storage/email/payment providers and transfer locations.
4. Whether UÚBA Plus is legally structured as a regulated subscription under the final checkout/renewal design, and the exact cancellation/refund implementation.
5. Final partner economics and FCA/SRA perimeter advice.
6. Final Article 9 / Schedule 1 condition mapping for special-category/criminal-offence data actually processed in production.
7. Full DPIA sign-off and records of processing.
8. Full accessibility test.
9. Final liability/indemnity drafting by UK counsel.

## Public sources checked
- ICO: right to be informed / privacy information.
- ICO: PECR cookies and similar technologies.
- Consumer Rights Act 2015.
- Consumer Contracts (Information, Cancellation and Additional Charges) Regulations 2013.
- Digital Markets, Competition and Consumers Act 2024 and 2026 subscription guidance/regulations.
- Company, Limited Liability Partnership and Business (Names and Trading Disclosures) Regulations 2015.
- FCA claims-management regulation and handbook definitions.
- SRA Code of Conduct referral/introduction requirements.
- OpenAI business/API privacy and Responses API storage guidance.
