# UÚBA Refunds & Complaints Operations

## Ownership
Private beta: UÚBA operator/admin.
Public launch: named Support & Complaints Lead plus deputy/cover.

## Monitoring cadence
- Check support/cancellation/refund queue each business day.
- Privacy/security complaints: immediate escalation.
- Review complaint trends monthly during beta and after any material incident.

## Targets
- Acknowledge within 2 business days.
- Routine refund/cancellation decision within 5 business days.
- Final complaint response within 10 business days or explain delay/revised date.

## Refund handling
1. Confirm purchaser/account and transaction.
2. Identify product: Plus monthly, Plus annual, or Specialist Review Pack.
3. Apply statutory cancellation/refund rights first.
4. Check whether service/digital performance started and what consent/acknowledgement checkout captured.
5. Record decision and reason.
6. Process approved refund to original payment method unless law/user agreement permits otherwise.
7. Send written confirmation.

## Launch blockers
- Configure support@uuba.co.uk and privacy@uuba.co.uk.
- Connect payment-provider refund tooling.
- Implement online subscription cancellation.
- Add order confirmation/durable-medium records.
- Obtain final legal review of checkout/refund wording.
