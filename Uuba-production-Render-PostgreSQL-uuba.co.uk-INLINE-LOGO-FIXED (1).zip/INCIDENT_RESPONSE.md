# HELPER Security and Personal Data Incident Plan — beta draft

1. Contain the incident: revoke keys/sessions, isolate affected service/storage.
2. Preserve minimal evidence needed to investigate.
3. Identify affected systems, data categories, users and time window.
4. Assess confidentiality, integrity and availability impact.
5. Determine whether the incident is a personal data breach and whether notification duties apply.
6. Escalate immediately to the named incident lead and data-protection adviser.
7. Notify affected processors and obtain their incident details.
8. Where required, notify the ICO within the applicable statutory period and affected individuals without undue delay where high risk applies.
9. Record the incident, decisions, mitigations and lessons learned even if no external notification is required.
10. Rotate affected credentials and verify restoration from clean backups.

Incident lead: [NAME / PHONE]
Privacy contact: [PRIVACY EMAIL]
Hosting emergency contact: [PROVIDER]
AI processor contact/process: [DETAILS]
