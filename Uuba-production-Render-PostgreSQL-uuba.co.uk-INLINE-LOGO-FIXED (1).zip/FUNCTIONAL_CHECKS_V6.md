# HELPER v6 functional checks

Specialist Review added to the main Specialist Help workspace.

Verified in a FastAPI TestClient run on 20 October 2026:

- `/` returned HTTP 200 and contained the interactive Specialist Review UI.
- A test user could register, create a saved case and call `POST /api/specialist-review`.
- Without an OpenAI API key the endpoint returned `mode: rules`, demonstrating the transparent fallback path.
- The review returned: case overview, accepted/disputed/unanswered points to verify, evidence index/gaps, specialist signals, professional-review issues, timing to verify, questions, next action and a copyable Specialist Review Pack.
- The API explicitly reports `document_contents_analysed: false`; uploaded files are indexed by metadata only and are not silently sent to AI.
- Live AI code path uses the same server-side OpenAI configuration as Ask HELPER/Response Analyser and requires both a configured API key and the user's AI opt-in.

## Safety boundary
The specialist review prompt expressly prohibits success percentages, strong/weak case labels, merits determinations, invented admissions, invented file contents, invented deadlines and guaranteed outcomes. It is designed as case preparation for human specialist review.
