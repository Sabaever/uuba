"""One-time migration from the prototype SQLite DB to production PostgreSQL.

Usage:
  export DATABASE_URL='postgresql://...'
  python migrate_sqlite_to_postgres.py --sqlite data/helper.db

Keep the same UUBA_ENCRYPTION_KEY that protected the SQLite data, otherwise
previously encrypted fields cannot be decrypted by the production app.
"""
from __future__ import annotations
import argparse, os, sqlite3
from pathlib import Path
from db_compat import init_database

TABLES = [
    "users", "sessions", "cases", "messages", "documents", "generated_letters",
    "audit_log", "community_posts", "community_reports", "rate_events",
]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--sqlite', default='data/helper.db')
    args=ap.parse_args()
    sqlite_path=Path(args.sqlite)
    database_url=os.getenv('DATABASE_URL','').strip()
    if not database_url.startswith(('postgresql://','postgres://')):
        raise SystemExit('DATABASE_URL must be a PostgreSQL URL.')
    if not sqlite_path.exists():
        raise SystemExit(f'SQLite DB not found: {sqlite_path}')

    import psycopg
    init_database(database_url, sqlite_path)
    src=sqlite3.connect(sqlite_path)
    src.row_factory=sqlite3.Row
    dst=psycopg.connect(database_url)
    try:
        with dst.cursor() as cur:
            for table in TABLES:
                rows=src.execute(f'SELECT * FROM {table} ORDER BY id').fetchall()
                if not rows:
                    print(f'{table}: 0 rows')
                    continue
                cols=rows[0].keys()
                names=','.join(cols)
                placeholders=','.join(['%s']*len(cols))
                assignments=','.join(f'{c}=EXCLUDED.{c}' for c in cols if c!='id')
                sql=f'INSERT INTO {table} ({names}) VALUES ({placeholders}) ON CONFLICT (id) DO UPDATE SET {assignments}'
                cur.executemany(sql,[tuple(r[c] for c in cols) for r in rows])
                cur.execute("SELECT pg_get_serial_sequence(%s, 'id')",(table,))
                seq=cur.fetchone()[0]
                if seq:
                    cur.execute(f"SELECT setval(%s, COALESCE((SELECT MAX(id) FROM {table}),1), (SELECT COUNT(*)>0 FROM {table}))",(seq,))
                print(f'{table}: {len(rows)} rows')
        dst.commit()
    except Exception:
        dst.rollback(); raise
    finally:
        dst.close(); src.close()
    print('Migration complete.')

if __name__=='__main__': main()
