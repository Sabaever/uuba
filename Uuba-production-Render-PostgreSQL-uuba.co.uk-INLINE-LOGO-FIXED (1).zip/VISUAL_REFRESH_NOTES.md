# HELPER visual refresh notes

## Design direction
- Keep blue as the primary trust colour.
- Add deep navy for stronger hierarchy and contrast.
- Use pale blue backgrounds only for supporting information, not every surface.
- Preserve white cards and generous spacing so the interface stays calm and consumer-friendly.

## Navigation changes
- Main header links now render as clear tab-like controls with borders/backgrounds.
- Start a case is emphasised in navy.
- Ask HELPER and Analyse a reply are emphasised in blue.
- On smaller screens the navigation remains visible as a horizontal scrolling tab bar instead of disappearing.
- Sub-navigation links are stronger rectangular tabs rather than faint pills.

## Content hierarchy changes
- Section headings now have clearer separators.
- Category guide cards use a stronger blue top edge and hover elevation.
- Primary calls to action have stronger contrast and hover states.
- Next-step cards have blue status bars.
- USP area uses a deeper navy gradient to separate it from general content.
- Form focus states are clearer for accessibility.

## Technical repair
A previous USP stylesheet block had accidentally been embedded in the generated-letter print function. It has been moved into the main page stylesheet and the print function has been repaired.
