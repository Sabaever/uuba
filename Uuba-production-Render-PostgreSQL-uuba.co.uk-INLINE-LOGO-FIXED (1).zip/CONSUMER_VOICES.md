# Consumer Voices v1

Consumer Voices is a moderated community area for HELPER users to share consumer experiences without exposing their private HELPER case file.

## Public pages

- `/consumer-voices` — approved community experiences, category/stage filters, search and reporting.
- `/consumer-voices/share` — signed-in submission form plus the user's own submission statuses and withdrawal controls.

## Safety/privacy design

- Community content is never copied automatically from a private case.
- New submissions are `pending` by default and invisible publicly until moderation approval.
- The form warns against addresses, account/policy/reference numbers, staff names, medical details, signatures and unredacted documents.
- Posts are labelled as personal experience, not verified legal guidance.
- Signed-in users can report approved posts.
- Users can withdraw their own submissions at any time.

## Moderation

Uses the existing `HELPER_ADMIN_TOKEN` environment variable.

- `GET /api/admin/community/pending`
- `POST /api/admin/community/posts/{post_id}/moderate`

Moderation body examples:

```json
{"action":"approve","note":""}
```

```json
{"action":"reject","note":"Contains personal information"}
```

Before public launch, build a moderator UI and have the community Terms/Privacy wording reviewed by UK legal counsel.

## v2 visibility + moderation dashboard

Consumer Voices is now surfaced directly on the HELPER home page in three places: the main navigation, the hero quick actions, and a dedicated homepage section with links to browse or share an experience.

A visual moderator dashboard is available at `/admin/community`. It uses the server-side `HELPER_ADMIN_TOKEN` and stores the entered token only in browser `sessionStorage`. The dashboard shows pending submissions, open reports, published/rejected counts, recent activity, approval/rejection controls, and report actions to keep, unpublish for re-review, or reject/remove a post.

The moderator page should not be linked from public navigation. Protect and rotate the admin token as a production secret.


## v4 navigation fix
Consumer Voices is now embedded directly in the main homepage. The main navigation jumps to `#consumer-voices`; opening a separate page is no longer required. The homepage also contains a recent-post feed that degrades safely in static/local preview mode. The standalone page remains available for the full community view.
