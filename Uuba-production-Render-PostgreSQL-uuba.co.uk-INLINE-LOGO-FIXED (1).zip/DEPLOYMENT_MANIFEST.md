# Uúba production package manifest

This build is based on the latest working Uúba site and retains the original 14-tab HELPER feature structure.

Production additions in this package:

- New photorealistic **Uúba** 3D star/space brand image in the homepage hero.
- Matching compact 3D header/footer brand asset and favicon.
- `render.yaml` defining the Render web service and Render PostgreSQL database.
- PostgreSQL compatibility layer (`db_compat.py`) while preserving SQLite for local development.
- PostgreSQL migration helper (`migrate_sqlite_to_postgres.py`).
- Production-only startup checks for PostgreSQL, secure cookies and a persistent encryption key.
- Secure response headers and trusted-host validation.
- Docker production startup using Render's `$PORT`.
- Production environment template and secret generator.
- Render/Wix domain deployment guide for `uuba.co.uk`.
- Go-live checklist and database migration notes.
- PostgreSQL backup helper.

Agreed pricing retained:

- Core — Free
- Plus — £6.99/month or £59/year
- AI Specialist Review + Pack — £24.99 one-off
