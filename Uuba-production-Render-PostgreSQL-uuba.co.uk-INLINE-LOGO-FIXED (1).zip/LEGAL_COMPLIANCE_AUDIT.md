# UÚBA legal/compliance website audit

Updated: 20 October 2026.

This pass used the public ComplianceFix scan checklist as a benchmark, not as legal certification. The scanner says it checks privacy/GDPR transparency, cookies/PECR, terms, accessibility, company information and sector/activity overlays.

## Added / strengthened
- Privacy Notice retained and linked site-wide.
- Terms retained; pre-launch paid-service/cancellation wording flagged for final legal sign-off.
- Cookie policy retained; current beta position remains strictly-necessary storage only unless non-essential technologies are introduced.
- Accessibility statement added with WCAG 2.2 AA as the target, without making an unverified conformance claim.
- Complaints procedure added.
- Company-information disclosure page added with explicit placeholders rather than invented company details.
- Legal footer links expanded on all HTML pages.
- Colour-contrast review included in the Colour Lab.

## Must be completed before public paid launch
1. Incorporate and fill legal company name, company number, registered office and place of registration.
2. Add VAT number if registered.
3. Replace support/privacy/accessibility email placeholders with @uuba.co.uk addresses.
4. Finalise paid-service cancellation/refund/subscription wording against the rules then in force and the exact checkout flow.
5. Select/confirm any ADR route only if applicable; do not claim participation before agreement.
6. Complete and record accessibility testing.
7. Confirm actual production processors, international transfers and safeguards in the Privacy Notice.
8. If analytics/marketing cookies are added, implement consent controls before loading them and list the actual trackers/cookies.
9. Obtain UK regulatory/commercial legal review for AI guidance, claims-management boundaries, specialist referrals/sponsorship and liability wording.
