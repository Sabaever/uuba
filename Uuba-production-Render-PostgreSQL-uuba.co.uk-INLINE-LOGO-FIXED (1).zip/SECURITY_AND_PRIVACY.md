# HELPER security and privacy notes

## Security controls in this build
- Argon2id password hashing.
- Opaque server-side sessions in HttpOnly, SameSite=Lax cookies.
- CSRF token required for state-changing authenticated routes.
- Per-user ownership checks for cases, messages and documents.
- Fernet authenticated encryption for sensitive text and files before storage.
- Optional S3 object storage: application-layer encryption occurs before upload; S3 server-side AES-256 encryption is also requested.
- Upload allow-list and size limit.
- Rate limiting persisted in the database for the single-server prototype.
- CSP, HSTS (production), frame denial, MIME sniffing protection, permissions policy.
- Audit events for security/privacy-sensitive operations.
- Data export and deletion endpoints.
- Closed-case retention cleanup via an authenticated admin job.
- Backups with checksums and configurable pruning.

## Privacy-by-default AI design
Live AI is opt-in at account level. When disabled, Ask HELPER uses only local verified rules. When enabled and an API key is configured, only the question, a minimised case context and the relevant verified guidance are sent to the AI provider. Complaint references are deliberately excluded from the AI context. Uploaded documents are not automatically sent to the model.

## Before public launch
Code is only one part of security/GDPR compliance. Before accepting real users, complete at least:
- DPIA and documented lawful bases/purposes.
- Final privacy/cookie notices and processor/subprocessor disclosures.
- Contracts/data-processing terms with hosting, storage, email and AI vendors.
- Production managed database, managed object storage and secrets manager.
- Email verification/password reset service and, ideally, MFA/passkeys.
- Malware scanning/content-disarm for uploaded documents.
- Centralised logs/monitoring, alerting and incident-response runbooks.
- Penetration test, dependency scanning and secure SDLC.
- Restore drills and documented recovery objectives.
- Back-up deletion policy aligned with erasure requests and retention cycles.
- Human governance for updates to consumer-law rules and source review dates.

## Retention model
The default account retention preference is 730 days and is configurable by the user between 30 and 3650 days. Automated retention deletes cases only after they have been marked Resolved/Closed and have exceeded the account's configured period. Account deletion removes live account data immediately. Backups follow their own configured retention period, default 30 days.
