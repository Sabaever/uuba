from __future__ import annotations

import base64, hashlib, hmac, io, json, os, re, secrets, shutil, sqlite3, time, zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from cryptography.fernet import Fernet
from fastapi import FastAPI, Request, Response, UploadFile, File, Form, HTTPException, Depends
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware
from db_compat import connect_db, init_database, is_postgres
from pydantic import BaseModel, EmailStr, Field

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
UPLOADS = DATA / "uploads"
BACKUPS = DATA / "backups"
DB = DATA / "helper.db"
KNOWLEDGE_PATH = ROOT / "knowledge.json"
for p in (DATA, UPLOADS, BACKUPS): p.mkdir(parents=True, exist_ok=True)

APP_ENV = os.getenv("UUBA_ENV", os.getenv("HELPER_ENV", "development"))
SESSION_DAYS = int(os.getenv("SESSION_DAYS", "7"))
RETENTION_DAYS = int(os.getenv("RETENTION_DAYS", "730"))
DELETED_ACCOUNT_GRACE_DAYS = int(os.getenv("DELETED_ACCOUNT_GRACE_DAYS", "30"))
RATE_LIMIT_PER_MIN = int(os.getenv("RATE_LIMIT_PER_MIN", "60"))
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "15"))
COOKIE_SECURE = os.getenv("COOKIE_SECURE", "0") == "1"
DATABASE_URL = os.getenv("DATABASE_URL", "").strip()
BASE_URL = os.getenv("UUBA_BASE_URL", "http://localhost:8000").strip().rstrip("/")
SESSION_COOKIE_NAME = os.getenv("SESSION_COOKIE_NAME", "uuba_session").strip() or "uuba_session"
TRUSTED_HOSTS = [h.strip() for h in os.getenv("TRUSTED_HOSTS", "localhost,127.0.0.1,uuba.co.uk,www.uuba.co.uk").split(",") if h.strip()]
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-6-luna")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
S3_BUCKET = os.getenv("S3_BUCKET", "").strip()
S3_PREFIX = os.getenv("S3_PREFIX", "uuba-private").strip().strip("/")
S3_REGION = os.getenv("S3_REGION", "").strip() or None
BETA_ACCESS_CODE = os.getenv("BETA_ACCESS_CODE", "").strip()
HELPER_ADMIN_TOKEN = os.getenv("UUBA_ADMIN_TOKEN", os.getenv("HELPER_ADMIN_TOKEN", "")).strip()

if APP_ENV == "production" and not is_postgres(DATABASE_URL):
    raise RuntimeError("DATABASE_URL must point to PostgreSQL in production.")
if APP_ENV == "production" and not COOKIE_SECURE:
    raise RuntimeError("COOKIE_SECURE=1 is required in production.")

ph = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=2)

def _load_or_create_fernet_key() -> bytes:
    env = os.getenv("UUBA_ENCRYPTION_KEY", os.getenv("HELPER_ENCRYPTION_KEY", "")).strip()
    if env:
        return env.encode()
    if APP_ENV == "production":
        raise RuntimeError("UUBA_ENCRYPTION_KEY is required in production. Generate it with python generate_secrets.py.")
    devkey = DATA / "dev_encryption.key"
    if devkey.exists():
        return devkey.read_bytes().strip()
    key = Fernet.generate_key()
    devkey.write_bytes(key)
    try: os.chmod(devkey, 0o600)
    except Exception: pass
    return key

fernet = Fernet(_load_or_create_fernet_key())


def storage_mode(): return "s3" if S3_BUCKET else "encrypted-local"

def store_blob(key: str, encrypted_data: bytes):
    if S3_BUCKET:
        import boto3
        boto3.client("s3", region_name=S3_REGION).put_object(Bucket=S3_BUCKET, Key=f"{S3_PREFIX}/{key}", Body=encrypted_data, ServerSideEncryption="AES256")
    else:
        path=UPLOADS/key; path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(encrypted_data)

def read_blob(key: str) -> bytes:
    if S3_BUCKET:
        import boto3
        return boto3.client("s3", region_name=S3_REGION).get_object(Bucket=S3_BUCKET, Key=f"{S3_PREFIX}/{key}")["Body"].read()
    return (UPLOADS/key).read_bytes()

def delete_blob(key: str):
    if S3_BUCKET:
        import boto3
        boto3.client("s3", region_name=S3_REGION).delete_object(Bucket=S3_BUCKET, Key=f"{S3_PREFIX}/{key}")
    else:
        (UPLOADS/key).unlink(missing_ok=True)

ALLOWED_TYPES = {
    "application/pdf", "image/jpeg", "image/png", "image/webp",
    "text/plain", "text/csv",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
}

with open(KNOWLEDGE_PATH, "r", encoding="utf-8") as f:
    KNOWLEDGE = json.load(f)

app = FastAPI(title="Uúba", version="1.0.0")
app.add_middleware(TrustedHostMiddleware, allowed_hosts=TRUSTED_HOSTS)
app.mount("/assets", StaticFiles(directory=ROOT / "assets"), name="assets")
app.mount("/legal", StaticFiles(directory=ROOT / "legal", html=True), name="legal")

@app.middleware("http")
async def production_security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    if APP_ENV == "production":
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    return response


def db():
    return connect_db(DATABASE_URL, DB)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def enc(value: Optional[str]) -> Optional[str]:
    if value is None: return None
    return fernet.encrypt(value.encode("utf-8")).decode("ascii")


def dec(value: Optional[str]) -> str:
    if not value: return ""
    try: return fernet.decrypt(value.encode("ascii")).decode("utf-8")
    except Exception: return "[unable to decrypt]"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def init_db():
    init_database(DATABASE_URL, DB)


init_db()


def audit(event: str, user_id: Optional[int] = None, meta: Optional[dict] = None):
    con = db(); con.execute("INSERT INTO audit_log(user_id,event,meta,created_at) VALUES(?,?,?,?)", (user_id,event,json.dumps(meta or {}),now_iso())); con.commit(); con.close()


def client_fingerprint(request: Request) -> str:
    ip = request.client.host if request.client else "unknown"
    ua = request.headers.get("user-agent", "")
    return hashlib.sha256(f"{ip}|{ua}".encode()).hexdigest()


def check_rate(request: Request, user_id: Optional[int]=None, limit: Optional[int]=None):
    limit = limit or RATE_LIMIT_PER_MIN
    bucket = f"u:{user_id}" if user_id else f"ip:{client_fingerprint(request)}"
    key = hashlib.sha256(bucket.encode()).hexdigest()
    cutoff = int(time.time()) - 60
    con = db()
    con.execute("DELETE FROM rate_events WHERE created_ts < ?", (cutoff-120,))
    count = con.execute("SELECT COUNT(*) FROM rate_events WHERE key_hash=? AND created_ts>=?", (key,cutoff)).fetchone()[0]
    if count >= limit:
        con.commit(); con.close(); raise HTTPException(429, "Too many requests. Please try again shortly.")
    con.execute("INSERT INTO rate_events(key_hash,created_ts) VALUES(?,?)", (key,int(time.time())))
    con.commit(); con.close()


def make_session(user_id: int, request: Request) -> tuple[str,str]:
    raw = secrets.token_urlsafe(32); csrf = secrets.token_urlsafe(24)
    expires = datetime.now(timezone.utc) + timedelta(days=SESSION_DAYS)
    con=db(); con.execute("INSERT INTO sessions(user_id,token_hash,csrf_token,created_at,expires_at,ip_hash,user_agent_hash) VALUES(?,?,?,?,?,?,?)",(
        user_id, token_hash(raw), csrf, now_iso(), expires.isoformat(),
        hashlib.sha256((request.client.host if request.client else "").encode()).hexdigest(),
        hashlib.sha256(request.headers.get("user-agent","").encode()).hexdigest()
    )); con.commit(); con.close(); return raw, csrf


def current_user(request: Request, require_csrf: bool=False):
    raw = request.cookies.get(SESSION_COOKIE_NAME)
    if not raw: raise HTTPException(401, "Please sign in.")
    con=db(); row=con.execute('''SELECT s.*,u.email,u.display_name_enc,u.deleted_at,u.retention_days,u.ai_enabled FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=?''',(token_hash(raw),)).fetchone()
    if not row: con.close(); raise HTTPException(401,"Session expired.")
    if row['deleted_at']: con.close(); raise HTTPException(401,"Account is pending deletion.")
    if datetime.fromisoformat(row['expires_at']) < datetime.now(timezone.utc):
        con.execute("DELETE FROM sessions WHERE id=?",(row['id'],)); con.commit(); con.close(); raise HTTPException(401,"Session expired.")
    if require_csrf:
        supplied=request.headers.get("x-csrf-token","")
        if not supplied or not hmac.compare_digest(supplied,row['csrf_token']): con.close(); raise HTTPException(403,"Invalid CSRF token.")
    user={"id":row['user_id'],"email":row['email'],"name":dec(row['display_name_enc']),"csrf":row['csrf_token'],"retention_days":row['retention_days'],"ai_enabled":bool(row['ai_enabled'])}
    con.close(); return user


def require_user(request: Request):
    return current_user(request, False)


def require_user_write(request: Request):
    return current_user(request, True)

class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=10, max_length=200)
    name: str = Field(min_length=1, max_length=100)
    marketing_consent: bool = False
    accept_terms: bool = False
    access_code: str = Field(default="", max_length=200)

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class CaseIn(BaseModel):
    organisation: str = Field(min_length=1, max_length=240)
    complaint_ref: str = Field(default="", max_length=200)
    category: str
    subcategory: str = Field(default="", max_length=200)
    problem_date: str = Field(default="", max_length=30)
    facts: str = Field(min_length=5, max_length=20000)
    desired_outcome: str = Field(default="", max_length=8000)
    details: dict = Field(default_factory=dict)

class LetterGenerateIn(BaseModel):
    letter_type: str = Field(min_length=1, max_length=100)
    extra_notes: str = Field(default="", max_length=6000)

class AskIn(BaseModel):
    question: str = Field(min_length=2, max_length=12000)
    case_id: Optional[int] = None

class AnalyseResponseIn(BaseModel):
    response_text: str = Field(min_length=10, max_length=30000)
    case_id: int

class SpecialistReviewIn(BaseModel):
    case_id: int
    extra_context: str = Field(default="", max_length=20000)

class RetentionIn(BaseModel):
    retention_days: int = Field(ge=30, le=3650)

class CaseStatusIn(BaseModel):
    status: str

class CommunityPostIn(BaseModel):
    alias: str = Field(min_length=2, max_length=60)
    category: str = Field(min_length=2, max_length=120)
    organisation: str = Field(default="", max_length=180)
    title: str = Field(min_length=5, max_length=140)
    story: str = Field(min_length=40, max_length=8000)
    tried: str = Field(default="", max_length=3000)
    helped: str = Field(default="", max_length=3000)
    outcome: str = Field(default="", max_length=3000)
    case_status: str = Field(default="Ongoing", max_length=30)
    consent_publication: bool = False

class CommunityReportIn(BaseModel):
    reason: str = Field(min_length=2, max_length=80)
    details: str = Field(default="", max_length=1500)

class CommunityModerationIn(BaseModel):
    action: str = Field(pattern="^(approve|reject)$")
    note: str = Field(default="", max_length=1000)

class CommunityReportResolutionIn(BaseModel):
    action: str = Field(pattern="^(keep|unpublish|reject)$")
    note: str = Field(default="", max_length=1000)

class AiPreferenceIn(BaseModel):
    enabled: bool


def case_to_dict(r):
    return {
        "id":r["id"], "organisation":dec(r["organisation_enc"]), "complaint_ref":dec(r["complaint_ref_enc"]),
        "category":r["category"], "subcategory":r["subcategory"] or "", "problem_date":r["problem_date"] or "",
        "facts":dec(r["facts_enc"]), "desired_outcome":dec(r["desired_outcome_enc"]), "status":r["status"],
        "details": json.loads(dec(r["case_meta_enc"]) or "{}") if "case_meta_enc" in r.keys() else {},
        "created_at":r["created_at"], "updated_at":r["updated_at"]
    }


def get_case_owned(user_id:int, case_id:int):
    con=db(); r=con.execute("SELECT * FROM cases WHERE id=? AND user_id=?",(case_id,user_id)).fetchone(); con.close()
    if not r: raise HTTPException(404,"Case not found.")
    return case_to_dict(r)


def local_rules_answer(question: str, case: Optional[dict]=None) -> str:
    q=question.lower()
    if re.search(r'(electrical|appliance|tv|television|washing machine|fridge|laptop|kettle).*(12|twelve).*(month|warranty|guarantee)|(12|twelve).*(month).*(warranty|guarantee)|all electrical.*warranty',q):
        return ("No. UK law does not require every electrical product to come with a 12-month manufacturer warranty. "
                "A warranty or guarantee is separate from your statutory rights. Goods bought from a trader must still meet the Consumer Rights Act standards. "
                "An expired warranty does not automatically end those rights. The first 30 days can matter for the short-term right to reject; during the first six months the evidential position is generally more favourable to the consumer; after six months rights can continue but evidence may become more important. "
                "In England and Wales, six years is generally a limitation period for bringing a breach-of-contract claim, not a six-year guarantee. If an electrical item fails after 12 months, contact the retailer and rely on your statutory rights rather than assuming the warranty expiry ends the matter.")
    if re.search(r'consumer rights act|how long.*consumer rights|rights.*last|six years|6 years',q):
        return ("Consumer Rights Act rights do not simply end after 30 days or six months. The first 30 days can provide a short-term right to reject qualifying faulty goods. During the first six months, the evidential rules are generally more favourable to the consumer. After six months, rights can continue but proof may become more important. In England and Wales, a breach-of-contract claim is generally subject to a six-year limitation period; that is not a six-year product guarantee.")
    if re.search(r'section 75|credit card',q):
        return "For qualifying purchases, Section 75 can make a credit-card provider jointly liable with the supplier for breach of contract or misrepresentation. It generally concerns items with a cash price over £100 and up to £30,000, subject to technical conditions."
    if re.search(r'14 day|fourteen day|cooling off|online.*cancel|cancel.*online',q):
        return "Many online, phone and other distance contracts have a 14-day cancellation period, but important exceptions apply and services or digital content can have additional rules once performance begins."
    if re.search(r'legal expenses|legal cover|home insurance.*legal|car insurance.*legal|insurance.*solicitor',q):
        return ("Before paying privately for legal help, check whether you already have legal-expenses insurance. It is often included with or sold alongside home or motor insurance, and depending on the policy it can cover employment, consumer-contract, property or personal-injury disputes. Also check trade-union, professional-body, credit-card or membership benefits. Contact the provider early because cover can depend on notification timing, exclusions and a reasonable-prospects-of-success test.")
    if re.search(r'acas|employment tribunal|dismissed|dismissal|grievance|workplace|employer',q) and not case:
        return ("If this is an employment problem, record the key dates first. A grievance or appeal does not stop the Employment Tribunal limitation clock. For problems happening on or after 1 October 2026, most tribunal claims have a 6 months minus 1 day limit, although older events and some special claims have different limits. You normally need to notify ACAS before making a tribunal claim, and timely Early Conciliation can pause the clock. If a deadline may be close, check the current ACAS time-limit guidance rather than waiting for an internal procedure to finish.")
    category=(case or {}).get('category')
    rule=KNOWLEDGE.get('categories',{}).get(category,{})
    if re.search(r'right|law|rule',q) and rule: return rule.get('rights','')
    if re.search(r'escalat|trigger|ombudsman|when can|deadline',q) and rule: return rule.get('trigger_points','')
    if re.search(r'evidence|document|proof|missing',q) and rule: return "Useful evidence: " + "; ".join(rule.get('evidence',[]))
    if rule: return rule.get('next_step','')
    return "I can help with consumer rights, warranties, cancellation rights, complaint trigger points, evidence and escalation. Select a saved case for case-specific guidance."



LETTER_OPTIONS = {
    "Buying goods": [
        ("faulty_goods", "Faulty goods — formal remedy request"),
        ("reject_goods", "Short-term rejection / refund request"),
        ("failed_repair", "Failed repair/replacement — final remedy request"),
        ("non_delivery", "Non-delivery / missing order complaint"),
        ("section75", "Section 75 / card-provider request"),
        ("chaser", "Complaint chaser / final response request"),
    ],
    "Trades & services": [
        ("poor_workmanship", "Poor workmanship — formal complaint"),
        ("incomplete_work", "Incomplete/delayed work — completion notice"),
        ("final_notice", "Final notice before escalation"),
    ],
    "Cars & garages": [
        ("faulty_vehicle", "Faulty vehicle — dealer complaint"),
        ("garage_work", "Garage repair / workmanship complaint"),
        ("car_finance", "Car-finance provider complaint"),
        ("chaser", "Dealer/garage complaint chaser"),
    ],
    "New-build home": [
        ("snagging_schedule", "New-build snagging / defect schedule cover letter"),
        ("formal_newbuild", "Formal developer complaint"),
        ("newbuild_chaser", "Missed complaint-stage / response chaser"),
        ("warranty_request", "NHBC / warranty-provider resolution request"),
        ("nhos_summary", "New Homes Ombudsman case summary"),
        ("urgent_defect", "Urgent serious-defect / safety notification"),
    ],
    "Energy": [
        ("energy_formal", "Energy supplier formal complaint"),
        ("energy_deadlock", "Deadlock / eight-week escalation request"),
        ("energy_ombudsman", "Energy Ombudsman case summary"),
    ],
    "Phone & broadband": [
        ("telecom_formal", "Phone/broadband formal complaint"),
        ("telecom_deadlock", "Deadlock / ADR eligibility request"),
        ("telecom_adr", "ADR case summary"),
    ],
    "Banking / finance / insurance": [
        ("finance_formal", "Bank/insurer/finance formal complaint"),
        ("finance_final", "Final-response / overdue-response request"),
        ("fos_summary", "Financial Ombudsman case summary"),
    ],
    "Travel": [
        ("travel_formal", "Airline/travel provider formal complaint"),
        ("travel_refund", "Refund / reimbursement request"),
        ("travel_adr", "Travel ADR / escalation summary"),
    ],
    "Digital / subscriptions": [
        ("digital_formal", "Digital service / subscription complaint"),
        ("subscription_cancel", "Cancellation and recurring-charge dispute"),
        ("digital_chaser", "Digital complaint chaser"),
    ],
    "Employment": [
        ("grievance", "Formal grievance"),
        ("appeal", "Appeal against disciplinary/grievance/dismissal outcome"),
        ("acas_summary", "ACAS Early Conciliation case summary"),
        ("pay_request", "Unpaid wages / pay discrepancy complaint"),
    ],
}

def _detail(case: dict, key: str, default: str="") -> str:
    return str((case.get("details") or {}).get(key) or default).strip()

def _case_identifiers(case: dict) -> list[str]:
    d=case.get("details") or {}
    mapping=[
        ("Case / complaint reference",case.get("complaint_ref","")),
        ("Account / order / booking / employee number",d.get("account_number","")),
        ("Property / product / service",d.get("subject","")),
        ("Property address",d.get("property_address","")),
        ("Plot number",d.get("plot_number","")),
        ("Development",d.get("development_name","")),
        ("Warranty / policy provider",d.get("warranty_provider","")),
        ("NHBC / warranty / policy number",d.get("warranty_number","")),
        ("Purchase / completion / contract date",d.get("contract_date","")),
        ("Amount paid / disputed",d.get("amount","")),
        ("Payment method",d.get("payment_method","")),
        ("Employer role / job title",d.get("job_title","")),
    ]
    return [f"{k}: {v}" for k,v in mapping if str(v).strip()]

def _letter_header(user: dict, case: dict, subject: str) -> str:
    today=datetime.now().strftime("%d %B %Y")
    sender=_detail(case,"correspondence_address")
    parts=[today]
    if user.get("name"): parts += [user["name"]]
    if sender: parts += [sender]
    parts += ["", f"To: {case.get('organisation','')}", f"Subject: {subject}"]
    ids=_case_identifiers(case)
    if ids: parts += ["", *ids]
    return "\n".join(parts)

def _facts_block(case: dict) -> str:
    facts=(case.get("facts") or "").strip()
    outcome=(case.get("desired_outcome") or "").strip()
    prior=_detail(case,"prior_contact")
    block=f"The key facts of my complaint are as follows:\n\n{facts}"
    if prior: block += f"\n\nPrevious contact / key dates:\n{prior}"
    if outcome: block += f"\n\nThe outcome I am seeking is:\n{outcome}"
    return block

def generate_case_letter(user: dict, case: dict, letter_type: str, extra_notes: str="") -> tuple[str,str]:
    opts=dict(LETTER_OPTIONS.get(case.get("category"),[]))
    if letter_type not in opts: raise HTTPException(400,"That letter type is not available for this case category.")
    title=opts[letter_type]
    ref=case.get("complaint_ref") or _detail(case,"account_number") or "your records"
    header=_letter_header(user,case,title)
    facts=_facts_block(case)
    extra=("\n\nAdditional points I want recorded:\n"+extra_notes.strip()) if extra_notes.strip() else ""
    deadline=_detail(case,"requested_response_date") or "14 days"
    close=f"\n\nPlease confirm receipt and provide a substantive written response within {deadline}, or tell me the applicable complaint timetable. Please keep all future communication in writing.\n\nYours faithfully,\n{user.get('name','')}"

    bodies={
      "faulty_goods": f"I am writing to make a formal complaint about goods supplied by you.\n\n{facts}\n\nI am relying on my statutory consumer rights. Please confirm which remedy you will provide and the timescale for doing so. A manufacturer's or retailer's warranty is separate from statutory rights and should not be treated as replacing them.",
      "reject_goods": f"I am writing to exercise the remedy I believe is available in relation to faulty/non-conforming goods.\n\n{facts}\n\nPlease confirm the return arrangements and refund process in writing. If you say the short-term right to reject does not apply, please explain why and identify the remedy you say is available.",
      "failed_repair": f"I have already allowed an attempt to repair/replace the goods, but the matter remains unresolved.\n\n{facts}\n\nPlease confirm the final remedy you propose, including any price reduction or refund where applicable, and explain your position in writing.",
      "non_delivery": f"I am making a formal complaint about non-delivery / incomplete delivery.\n\n{facts}\n\nPlease either complete delivery by an agreed date or confirm the refund/cancellation remedy available to me. Please do not refer me solely to the courier where my contract is with you.",
      "section75": f"I am asking you to assess a potential Section 75 and/or other card-provider remedy arising from a supplier breach or misrepresentation.\n\n{facts}\n\nPlease confirm which remedy you are assessing, whether you require any additional evidence, and the complaint reference for this request.",
      "poor_workmanship": f"I am making a formal complaint about the quality of services/work carried out.\n\n{facts}\n\nPlease set out how and when you will put the work right. If repeat performance is not possible, cannot be completed within a reasonable time, or would cause significant inconvenience, please explain the alternative remedy you propose.",
      "incomplete_work": f"I am writing about incomplete or delayed work.\n\n{facts}\n\nPlease provide a written completion plan, including dates and the person responsible for the outstanding work. If you cannot complete it within a reasonable period, please propose an alternative resolution.",
      "final_notice": f"This is my final request for resolution before I consider the appropriate ADR, trade-body, card-provider, legal-expenses-insurer or court route.\n\n{facts}\n\nPlease provide your final position and any applicable ADR details.",
      "faulty_vehicle": f"I am making a formal complaint about a vehicle supplied by you.\n\n{facts}\n\nPlease confirm your proposed remedy and timescale. My statutory rights are separate from any manufacturer's/dealer warranty. If you dispute responsibility, please explain your factual and legal basis in writing.",
      "garage_work": f"I am making a formal complaint about garage repair/service work.\n\n{facts}\n\nPlease inspect the vehicle/work and set out the rectification you propose, the timescale, and whether any further cost is disputed or accepted.",
      "car_finance": f"I am making a formal complaint in relation to vehicle finance and the underlying vehicle/supplier issue.\n\n{facts}\n\nPlease investigate the complaint under your regulated complaints process, confirm the complaint reference, and provide your final response within the applicable timeframe.",
      "snagging_schedule": f"I am submitting my snagging/defect schedule for the property identified above.\n\n{facts}\n\nPlease acknowledge each numbered item, confirm whether it is accepted, give the proposed remedy, identify the responsible trade and provide target attendance/completion dates. Please do not close an item until I have had an opportunity to verify the completed work.",
      "formal_newbuild": f"Please treat this as a formal complaint under your published complaints procedure and any applicable New Homes Quality Code requirements.\n\n{facts}\n\nPlease confirm the complaint stage, the person responsible for managing it, the timetable for the next formal response, and a dated plan for all outstanding defects/actions.",
      "newbuild_chaser": f"I am chasing an overdue response/action in my new-build complaint.\n\n{facts}\n\nPlease confirm which complaint stage has been reached, which response is now due, and when it will be issued. If you consider the complaint closed or at deadlock, please send the relevant closure/final response and explain the escalation route.",
      "warranty_request": f"I am asking the warranty provider to consider the unresolved defects and the builder/developer's response under the applicable policy/resolution process.\n\n{facts}\n\nPlease confirm whether the matter falls within the builder warranty/resolution stage or another part of the policy, what evidence you require, and the next formal step.",
      "nhos_summary": f"I am preparing this summary for New Homes Ombudsman consideration.\n\n{facts}\n\nI ask that the complaint record, developer responses, applicable Code obligations, defect evidence and remedy sought are considered together. I have kept the chronology and supporting documents available for submission.",
      "urgent_defect": f"I am reporting an urgent defect / potential safety or serious habitability issue requiring prompt attention.\n\n{facts}\n\nPlease confirm immediately what temporary safety measures are required, who will attend, and the timetable for permanent repair. This notification is without prejudice to my formal complaint and warranty rights.",
      "energy_formal": f"Please treat this as a formal complaint about my energy account/supply.\n\n{facts}\n\nPlease investigate the disputed issue, correct any inaccurate account information where appropriate, and confirm the resolution in writing together with my complaint reference.",
      "energy_deadlock": f"My energy complaint remains unresolved.\n\n{facts}\n\nPlease confirm whether you are issuing a deadlock/final response. If you say I must wait longer, please confirm the date on which the applicable Ombudsman waiting period expires.",
      "energy_ombudsman": f"I am preparing this summary for the Energy Ombudsman.\n\n{facts}\n\nThe supplier has had the opportunity to resolve the complaint. I ask that the chronology, bills/readings, complaint responses and remedy sought are considered together.",
      "telecom_formal": f"Please treat this as a formal complaint about my phone/broadband service/account.\n\n{facts}\n\nPlease investigate, confirm the complaint reference, explain your proposed remedy and identify the ADR scheme that covers the account.",
      "telecom_deadlock": f"My telecom complaint remains unresolved.\n\n{facts}\n\nPlease issue a deadlock/final response if you have reached your final position, or confirm the exact date on which I become eligible to use ADR under the applicable rules.",
      "telecom_adr": f"I am preparing this case summary for telecom ADR.\n\n{facts}\n\nPlease consider the service/account evidence, complaint chronology, provider responses and remedy sought.",
      "finance_formal": f"Please treat this as a formal regulated complaint.\n\n{facts}\n\nPlease investigate, confirm the complaint reference, preserve relevant records, and issue your final response within the applicable complaints-handling timeframe.",
      "finance_final": f"My financial-services complaint remains unresolved and I am requesting your final response / an explanation of the applicable response deadline.\n\n{facts}\n\nPlease state your final position clearly, include Financial Ombudsman referral rights where applicable, and identify the date from which any referral deadline runs.",
      "fos_summary": f"I am preparing this complaint summary for the Financial Ombudsman Service.\n\n{facts}\n\nI ask that the firm's final response, transaction/policy evidence, complaint chronology and remedy sought are considered together.",
      "travel_formal": f"Please treat this as a formal travel complaint.\n\n{facts}\n\nPlease confirm which legal/contractual passenger or package-travel rules you have considered, the remedy you propose, and any ADR scheme available if the matter remains unresolved.",
      "travel_refund": f"I am requesting the refund/reimbursement identified in my complaint.\n\n{facts}\n\nPlease confirm the amount accepted, any amount disputed and your reasons, together with the payment date for any sum due.",
      "travel_adr": f"I am preparing this summary for the relevant travel ADR/escalation process.\n\n{facts}\n\nPlease consider the booking, disruption/cancellation evidence, expenses, provider correspondence and remedy sought.",
      "digital_formal": f"Please treat this as a formal complaint concerning digital content/service/subscription.\n\n{facts}\n\nPlease confirm whether you will repair/restore access, replace/re-perform, refund or reduce the price as appropriate, and provide your reasons in writing.",
      "subscription_cancel": f"I am disputing continued subscription/recurring charges and confirming my cancellation position.\n\n{facts}\n\nPlease confirm the cancellation date, stop any unauthorised future charges, and explain/refund any disputed sums as appropriate.",
      "digital_chaser": f"My digital-service complaint remains unresolved.\n\n{facts}\n\nPlease provide your final position, the remedy proposed and any escalation/ADR route available.",
      "grievance": f"Please treat this as a formal grievance under your grievance procedure.\n\n{facts}\n\nPlease confirm who will investigate, the next procedural step and the proposed timetable. I ask that relevant records are preserved and that I am given a fair opportunity to provide evidence and respond.",
      "appeal": f"I am appealing the outcome communicated to me.\n\n{facts}\n\nMy grounds of appeal are the factual/procedural issues set out above. Please confirm the appeal process, decision-maker and hearing/timetable. This appeal does not waive any statutory time limits that may apply.",
      "acas_summary": f"I am preparing this summary for ACAS Early Conciliation.\n\n{facts}\n\nKey dates are important because internal grievance or appeal procedures do not themselves stop Employment Tribunal limitation periods. I have set out the remedy I am seeking and the steps already taken internally.",
      "pay_request": f"I am raising a formal complaint about pay/wages/holiday pay or another payment due.\n\n{facts}\n\nPlease provide the calculation you rely on, correct any underpayment identified and confirm when payment will be made.",
      "chaser": f"I am following up my unresolved complaint.\n\n{facts}\n\nPlease confirm the current complaint stage, your substantive response and the date of the next action. If this is your final position, please say so clearly and provide the applicable escalation information.",
    }
    body=bodies.get(letter_type, f"I am writing about my complaint.\n\n{facts}") + extra + close
    return title, header + "\n\nDear Sir or Madam,\n\n" + body

def build_grounding(case: Optional[dict]) -> dict:
    if not case: return {"general":KNOWLEDGE.get("general",{}),"category":None}
    return {"general":KNOWLEDGE.get("general",{}),"category":KNOWLEDGE.get("categories",{}).get(case.get("category"),{})}


def live_ai_answer(question: str, case: Optional[dict], allow_live: bool=True) -> tuple[str,str]:
    if not OPENAI_API_KEY or not allow_live:
        return local_rules_answer(question,case), "rules"
    try:
        from openai import OpenAI
        client=OpenAI(api_key=OPENAI_API_KEY)
        grounding=build_grounding(case)
        case_context={k:(case or {}).get(k) for k in ("organisation","category","subcategory","problem_date","facts","desired_outcome","status") if (case or {}).get(k) not in (None,"")}
        system=("You are Ask HELPER, a UK consumer-support assistant. Give calm, plain-English, practical information and case-management support. "
                "HELPER is not a law firm, does not provide legal representation, and must never guarantee, predict or imply a successful outcome, compensation award or legal result. "
                "Use ONLY the supplied HELPER verified guidance for legal deadlines, statutory rights, regulators, ombudsmen, ADR eligibility and escalation routes. Do not invent or infer a legal rule that is not present in that verified guidance. "
                "If the verified guidance does not support a legal proposition, say you cannot confirm it, identify what needs checking, and direct the user to the relevant official source or independent professional advice. "
                "Clearly distinguish statutory rights from voluntary warranties and distinguish information from legal advice. Prefer one clear next action, followed only by the most important supporting steps. "
                "If a deadline may be urgent, uncertain or case-dependent, say so prominently and recommend checking the current official guidance or obtaining qualified advice rather than calculating beyond the verified material. "
                "If the user pastes a company reply, separate: (1) what the organisation has answered, (2) what remains unanswered or unsupported, (3) what evidence may still be useful, and (4) the sensible next response or trigger point. "
                "Never say a message has been sent, never claim to have reviewed a document that was not supplied, and never present AI-generated text as authoritative legal advice.")
        payload={"case":case_context,"verified_helper_guidance":grounding,"question":question}
        response=client.responses.create(
            model=OPENAI_MODEL,
            instructions=system,
            input=json.dumps(payload,ensure_ascii=False),
            store=False,
        )
        text=(response.output_text or "").strip()
        if not text: raise RuntimeError("empty AI response")
        return text,"openai"
    except Exception as e:
        audit("ai_fallback", case.get("user_id") if case else None, {"error":str(e)[:300]})
        return local_rules_answer(question,case),"rules-fallback"

@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"]="nosniff"
    response.headers["X-Frame-Options"]="DENY"
    response.headers["Referrer-Policy"]="strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"]="camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"]="default-src 'self'; img-src 'self' data: https://images.unsplash.com; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
    if APP_ENV == "production": response.headers["Strict-Transport-Security"]="max-age=31536000; includeSubDomains"
    return response

@app.get("/", response_class=HTMLResponse)
def root(): return FileResponse(ROOT/"index.html")

@app.get("/specialists", response_class=HTMLResponse)
def specialists_page(): return FileResponse(ROOT/"specialists.html")

@app.get("/specialists.html", response_class=HTMLResponse)
def specialists_page_html(): return FileResponse(ROOT/"specialists.html")

@app.get("/consumer-voices", response_class=HTMLResponse)
def consumer_voices_page(): return FileResponse(ROOT/"consumer-voices.html")

@app.get("/consumer-voices.html", response_class=HTMLResponse)
def consumer_voices_page_html(): return FileResponse(ROOT/"consumer-voices.html")

@app.get("/consumer-voices/share", response_class=HTMLResponse)
def consumer_voices_share_page(): return FileResponse(ROOT/"consumer-voices-share.html")

@app.get("/consumer-voices-share.html", response_class=HTMLResponse)
def consumer_voices_share_page_html(): return FileResponse(ROOT/"consumer-voices-share.html")

@app.get("/admin/community", response_class=HTMLResponse)
def community_moderator_page(): return FileResponse(ROOT/"community-moderator.html")

@app.get("/community-moderator.html", response_class=HTMLResponse)
def community_moderator_page_html(): return FileResponse(ROOT/"community-moderator.html")

@app.get("/api/health")
def health():
    try:
        con = db(); con.execute("SELECT 1").fetchone(); con.close()
    except Exception:
        raise HTTPException(503, "Database unavailable.")
    return {"ok":True,"environment":APP_ENV,"database":"postgresql" if is_postgres(DATABASE_URL) else "sqlite","ai":"openai" if OPENAI_API_KEY else "rules-fallback","model":OPENAI_MODEL if OPENAI_API_KEY else None,"storage":storage_mode(),"retention_days":RETENTION_DAYS,"private_beta":bool(BETA_ACCESS_CODE),"base_url":BASE_URL}

@app.post("/api/auth/register")
def register(data:RegisterIn, request:Request, response:Response):
    check_rate(request,limit=10)
    email=data.email.lower().strip()
    if not data.accept_terms:
        raise HTTPException(400,"You must accept the Uúba Terms and Privacy Notice to create an account.")
    if BETA_ACCESS_CODE and not secrets.compare_digest(data.access_code.strip(), BETA_ACCESS_CODE):
        raise HTTPException(403,"A valid private-beta access code is required.")
    con=db()
    if con.execute("SELECT 1 FROM users WHERE email=?",(email,)).fetchone(): con.close(); raise HTTPException(409,"An account with this email already exists.")
    ts=now_iso(); cur=con.execute("INSERT INTO users(email,password_hash,display_name_enc,created_at,updated_at,retention_days,marketing_consent,terms_accepted_at,terms_version,privacy_version) VALUES(?,?,?,?,?,?,?,?,?,?)",(email,ph.hash(data.password),enc(data.name.strip()),ts,ts,RETENTION_DAYS,int(data.marketing_consent),ts,"2026-10-16-beta1","2026-10-16-beta1"))
    uid=cur.lastrowid; con.commit(); con.close()
    raw,csrf=make_session(uid,request)
    response.set_cookie(SESSION_COOKIE_NAME,raw,httponly=True,secure=COOKIE_SECURE,samesite="lax",max_age=SESSION_DAYS*86400,path="/")
    audit("register",uid)
    return {"ok":True,"user":{"id":uid,"email":email,"name":data.name.strip()},"csrf":csrf}

@app.post("/api/auth/login")
def login(data:LoginIn, request:Request, response:Response):
    check_rate(request,limit=12); email=data.email.lower().strip(); con=db(); r=con.execute("SELECT * FROM users WHERE email=?",(email,)).fetchone(); con.close()
    if not r or r['deleted_at']: raise HTTPException(401,"Invalid email or password.")
    try: ph.verify(r['password_hash'],data.password)
    except VerifyMismatchError: raise HTTPException(401,"Invalid email or password.")
    if ph.check_needs_rehash(r['password_hash']):
        con=db(); con.execute("UPDATE users SET password_hash=?,updated_at=? WHERE id=?",(ph.hash(data.password),now_iso(),r['id'])); con.commit(); con.close()
    raw,csrf=make_session(r['id'],request); response.set_cookie(SESSION_COOKIE_NAME,raw,httponly=True,secure=COOKIE_SECURE,samesite="lax",max_age=SESSION_DAYS*86400,path="/")
    con=db(); con.execute("UPDATE users SET last_login_at=? WHERE id=?",(now_iso(),r['id'])); con.commit(); con.close(); audit("login",r['id'])
    return {"ok":True,"user":{"id":r['id'],"email":r['email'],"name":dec(r['display_name_enc'])},"csrf":csrf}

@app.post("/api/auth/logout")
def logout(request:Request,response:Response):
    raw=request.cookies.get(SESSION_COOKIE_NAME)
    if raw:
        con=db(); con.execute("DELETE FROM sessions WHERE token_hash=?",(token_hash(raw),)); con.commit(); con.close()
    response.delete_cookie(SESSION_COOKIE_NAME,path="/"); return {"ok":True}

@app.get("/api/me")
def me(request:Request):
    u=current_user(request); return {"user":{"id":u['id'],"email":u['email'],"name":u['name'],"retention_days":u['retention_days'],"ai_enabled":u['ai_enabled']},"csrf":u['csrf']}

@app.post("/api/cases")
def create_case(data:CaseIn, request:Request):
    u=current_user(request,True); check_rate(request,u['id'],30)
    if data.category not in KNOWLEDGE.get("categories",{}): raise HTTPException(400,"Unknown category.")
    ts=now_iso(); con=db(); cur=con.execute('''INSERT INTO cases(user_id,organisation_enc,complaint_ref_enc,category,subcategory,problem_date,facts_enc,desired_outcome_enc,case_meta_enc,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',(
        u['id'],enc(data.organisation.strip()),enc(data.complaint_ref.strip()),data.category,data.subcategory.strip(),data.problem_date.strip(),enc(data.facts.strip()),enc(data.desired_outcome.strip()),enc(json.dumps(data.details or {},ensure_ascii=False)),"Open",ts,ts))
    con.commit(); r=con.execute("SELECT * FROM cases WHERE id=?",(cur.lastrowid,)).fetchone(); con.close(); audit("case_created",u['id'],{"case_id":r['id'],"category":data.category}); return {"case":case_to_dict(r)}

@app.put("/api/cases/{case_id}")
def update_case(case_id:int, data:CaseIn, request:Request):
    u=current_user(request,True); check_rate(request,u['id'],30); get_case_owned(u['id'],case_id)
    if data.category not in KNOWLEDGE.get("categories",{}): raise HTTPException(400,"Unknown category.")
    con=db(); con.execute("UPDATE cases SET organisation_enc=?,complaint_ref_enc=?,category=?,subcategory=?,problem_date=?,facts_enc=?,desired_outcome_enc=?,case_meta_enc=?,updated_at=? WHERE id=? AND user_id=?",(
        enc(data.organisation.strip()),enc(data.complaint_ref.strip()),data.category,data.subcategory.strip(),data.problem_date.strip(),enc(data.facts.strip()),enc(data.desired_outcome.strip()),enc(json.dumps(data.details or {},ensure_ascii=False)),now_iso(),case_id,u['id']))
    con.commit(); r=con.execute("SELECT * FROM cases WHERE id=?",(case_id,)).fetchone(); con.close(); audit("case_updated",u['id'],{"case_id":case_id}); return {"case":case_to_dict(r)}

@app.get("/api/cases")
def list_cases(request:Request):
    u=current_user(request); con=db(); rows=con.execute("SELECT * FROM cases WHERE user_id=? ORDER BY updated_at DESC",(u['id'],)).fetchall(); con.close(); return {"cases":[case_to_dict(r) for r in rows]}

@app.get("/api/cases/{case_id}")
def get_case(case_id:int, request:Request): return {"case":get_case_owned(current_user(request)['id'],case_id)}

@app.put("/api/cases/{case_id}/status")
def update_case_status(case_id:int, data:CaseStatusIn, request:Request):
    u=current_user(request,True); get_case_owned(u['id'],case_id)
    status=data.status.strip().title()
    if status not in {"Open","Resolved","Closed"}: raise HTTPException(400,"Status must be Open, Resolved or Closed.")
    closed=now_iso() if status in {"Resolved","Closed"} else None
    con=db(); con.execute("UPDATE cases SET status=?,closed_at=?,updated_at=? WHERE id=? AND user_id=?",(status,closed,now_iso(),case_id,u['id'])); con.commit(); con.close(); audit("case_status",u['id'],{"case_id":case_id,"status":status}); return {"ok":True,"status":status}

@app.delete("/api/cases/{case_id}")
def delete_case(case_id:int, request:Request):
    u=current_user(request,True); get_case_owned(u['id'],case_id)
    con=db(); docs=con.execute("SELECT stored_key FROM documents WHERE case_id=? AND user_id=?",(case_id,u['id'])).fetchall(); con.execute("DELETE FROM cases WHERE id=? AND user_id=?",(case_id,u['id'])); con.commit(); con.close()
    for d in docs:
        try:delete_blob(d['stored_key'])
        except Exception:pass
    audit("case_deleted",u['id'],{"case_id":case_id}); return {"ok":True}


@app.get("/api/cases/{case_id}/letter-options")
def letter_options(case_id:int, request:Request):
    u=current_user(request); case=get_case_owned(u['id'],case_id)
    return {"options":[{"id":k,"label":v} for k,v in LETTER_OPTIONS.get(case.get("category"),[])]}

@app.post("/api/cases/{case_id}/letters")
def create_letter(case_id:int, data:LetterGenerateIn, request:Request):
    u=current_user(request,True); check_rate(request,u['id'],30); case=get_case_owned(u['id'],case_id)
    title,body=generate_case_letter(u,case,data.letter_type,data.extra_notes)
    con=db(); cur=con.execute("INSERT INTO generated_letters(user_id,case_id,letter_type,title_enc,body_enc,created_at) VALUES(?,?,?,?,?,?)",(u['id'],case_id,data.letter_type,enc(title),enc(body),now_iso())); con.commit(); lid=cur.lastrowid; con.close()
    audit("letter_generated",u['id'],{"case_id":case_id,"letter_id":lid,"type":data.letter_type})
    return {"letter":{"id":lid,"title":title,"body":body,"letter_type":data.letter_type}}

@app.get("/api/cases/{case_id}/letters")
def list_letters(case_id:int, request:Request):
    u=current_user(request); get_case_owned(u['id'],case_id); con=db(); rows=con.execute("SELECT * FROM generated_letters WHERE user_id=? AND case_id=? ORDER BY id DESC",(u['id'],case_id)).fetchall(); con.close()
    return {"letters":[{"id":r['id'],"title":dec(r['title_enc']),"letter_type":r['letter_type'],"body":dec(r['body_enc']),"created_at":r['created_at']} for r in rows]}

@app.get("/api/letters/{letter_id}/download")
def download_letter(letter_id:int, request:Request):
    u=current_user(request); con=db(); r=con.execute("SELECT * FROM generated_letters WHERE id=? AND user_id=?",(letter_id,u['id'])).fetchone(); con.close()
    if not r: raise HTTPException(404,"Letter not found.")
    title=dec(r['title_enc']) or "HELPER letter"; body=dec(r['body_enc'])
    safe=re.sub(r"[^A-Za-z0-9._-]+","-",title).strip("-")[:80] or "helper-letter"
    return StreamingResponse(io.BytesIO(body.encode("utf-8")),media_type="text/plain; charset=utf-8",headers={"Content-Disposition":f'attachment; filename="{safe}.txt"'})

@app.delete("/api/letters/{letter_id}")
def delete_letter(letter_id:int, request:Request):
    u=current_user(request,True); con=db(); r=con.execute("SELECT id FROM generated_letters WHERE id=? AND user_id=?",(letter_id,u['id'])).fetchone()
    if not r: con.close(); raise HTTPException(404,"Letter not found.")
    con.execute("DELETE FROM generated_letters WHERE id=?",(letter_id,)); con.commit(); con.close(); audit("letter_deleted",u['id'],{"letter_id":letter_id}); return {"ok":True}

@app.post("/api/cases/{case_id}/documents")
async def upload_document(case_id:int, request:Request, file:UploadFile=File(...)):
    u=current_user(request,True); check_rate(request,u['id'],20); get_case_owned(u['id'],case_id)
    data=await file.read(MAX_UPLOAD_MB*1024*1024+1)
    if len(data)>MAX_UPLOAD_MB*1024*1024: raise HTTPException(413,f"Maximum upload is {MAX_UPLOAD_MB} MB.")
    ctype=(file.content_type or "application/octet-stream").lower()
    if ctype not in ALLOWED_TYPES: raise HTTPException(415,"This file type is not allowed in the prototype.")
    key=f"{u['id']}/{secrets.token_hex(16)}.bin"; encrypted=fernet.encrypt(data); store_blob(key,encrypted)
    con=db(); cur=con.execute("INSERT INTO documents(user_id,case_id,original_name_enc,stored_key,content_type,size_bytes,sha256,created_at) VALUES(?,?,?,?,?,?,?,?)",(u['id'],case_id,enc(file.filename or 'document'),key,ctype,len(data),sha256(data),now_iso())); con.commit(); did=cur.lastrowid; con.close(); audit("document_uploaded",u['id'],{"case_id":case_id,"document_id":did,"content_type":ctype,"size":len(data)}); return {"document":{"id":did,"name":file.filename,"content_type":ctype,"size":len(data)}}

@app.get("/api/cases/{case_id}/documents")
def list_documents(case_id:int, request:Request):
    u=current_user(request); get_case_owned(u['id'],case_id); con=db(); rows=con.execute("SELECT id,original_name_enc,content_type,size_bytes,created_at FROM documents WHERE case_id=? AND user_id=? ORDER BY id DESC",(case_id,u['id'])).fetchall(); con.close(); return {"documents":[{"id":r['id'],"name":dec(r['original_name_enc']),"content_type":r['content_type'],"size":r['size_bytes'],"created_at":r['created_at']} for r in rows]}

@app.get("/api/documents/{document_id}/download")
def download_document(document_id:int, request:Request):
    u=current_user(request); con=db(); r=con.execute("SELECT * FROM documents WHERE id=? AND user_id=?",(document_id,u['id'])).fetchone(); con.close()
    if not r: raise HTTPException(404,"Document not found.")
    raw=fernet.decrypt(read_blob(r['stored_key'])); name=dec(r['original_name_enc']) or 'document'; return StreamingResponse(io.BytesIO(raw),media_type=r['content_type'],headers={"Content-Disposition":f'attachment; filename="{name.replace(chr(34),"")}"'})

@app.delete("/api/documents/{document_id}")
def delete_document(document_id:int, request:Request):
    u=current_user(request,True); con=db(); r=con.execute("SELECT * FROM documents WHERE id=? AND user_id=?",(document_id,u['id'])).fetchone()
    if not r: con.close(); raise HTTPException(404,"Document not found.")
    con.execute("DELETE FROM documents WHERE id=?",(document_id,)); con.commit(); con.close(); delete_blob(r['stored_key']); audit("document_deleted",u['id'],{"document_id":document_id}); return {"ok":True}

@app.post("/api/ask")
def ask(data:AskIn, request:Request):
    u=current_user(request,True); check_rate(request,u['id'],20); case=get_case_owned(u['id'],data.case_id) if data.case_id else None
    answer,mode=live_ai_answer(data.question,case,u.get("ai_enabled",False))
    con=db(); ts=now_iso(); con.execute("INSERT INTO messages(user_id,case_id,role,content_enc,ai_mode,created_at) VALUES(?,?,?,?,?,?)",(u['id'],data.case_id,"user",enc(data.question),None,ts)); con.execute("INSERT INTO messages(user_id,case_id,role,content_enc,ai_mode,created_at) VALUES(?,?,?,?,?,?)",(u['id'],data.case_id,"helper",enc(answer),mode,ts)); con.commit(); con.close(); audit("ask_helper",u['id'],{"case_id":data.case_id,"mode":mode}); return {"answer":answer,"mode":mode,"grounded":True}


def rules_response_analysis(case: dict, response_text: str) -> dict:
    guidance=KNOWLEDGE.get("categories",{}).get(case.get("category"),{})
    text=response_text.lower()
    checks=guidance.get("case_review_questions",[])
    evidence=guidance.get("evidence",[])
    answered=[]; unanswered=[]
    keyword_groups={
      "remedy":["refund","repair","replace","credit","compensation","remedy","offer","works"],
      "position":["accept","accepted","reject","rejected","deny","denied","liability","decision"],
      "timing":["day","week","date","deadline","within","response","deadlock","final response"],
      "evidence":["report","photo","invoice","receipt","statement","evidence","meter","diagnostic"],
      "escalation":["ombudsman","adr","appeal","acas","tribunal","court","deadlock"]
    }
    seen={k:any(w in text for w in ws) for k,ws in keyword_groups.items()}
    if seen['position']: answered.append("The reply appears to state at least part of the organisation's position on acceptance/rejection.")
    else: unanswered.append("The organisation's position on what it accepts or rejects is not clearly identifiable from this reply.")
    if seen['remedy']: answered.append("The reply appears to mention a remedy, proposed action or offer; check whether it covers every issue in your case.")
    else: unanswered.append("No clear remedy, corrective action or offer is identifiable.")
    if seen['timing']: answered.append("The reply appears to include timing or complaint-stage language; compare it with the verified trigger for this category.")
    else: unanswered.append("No clear timetable, final-response status or next response date is identifiable.")
    if not seen['escalation']: unanswered.append("The reply does not clearly identify an escalation/ADR/appeal route.")
    return {
      "answered": answered or ["A rules-only review cannot reliably determine which factual points were answered; enable live AI for detailed semantic analysis."],
      "unanswered": unanswered,
      "evidence": evidence[:6],
      "trigger": guidance.get("trigger_points","Check the verified category guidance for the next trigger point."),
      "next_step": guidance.get("next_step","Compare the reply against your complaint and ask the organisation to answer the outstanding points."),
      "review_questions": checks,
      "mode":"rules",
      "warning":"Rules-only mode is a checklist review, not a legal assessment. It may miss meaning in the reply."
    }

def live_response_analysis(case: dict, response_text: str, allow_live: bool) -> dict:
    fallback=rules_response_analysis(case,response_text)
    if not OPENAI_API_KEY or not allow_live: return fallback
    try:
        from openai import OpenAI
        client=OpenAI(api_key=OPENAI_API_KEY)
        guidance=build_grounding(case)
        instructions=("You are HELPER Response Analyser for UK consumer cases. Analyse ONLY the supplied organisation reply against the saved case and verified HELPER guidance. "
          "Return valid JSON only with keys answered, unanswered, evidence, trigger, next_step, review_questions, warning. Each of answered/unanswered/evidence/review_questions must be arrays of concise strings; trigger and next_step concise strings. "
          "Do not invent legal rights, deadlines, admissions, facts or likely outcomes. Do not predict success. If a point is ambiguous say it is unclear. Distinguish what the reply actually says from what HELPER guidance says. "
          "For trigger/deadline statements use only supplied verified guidance; otherwise say it needs checking. Recommend qualified advice for urgent, high-value, technically complex, litigation or uncertain deadline issues.")
        payload={"case":{k:case.get(k) for k in ('organisation','category','subcategory','problem_date','facts','desired_outcome','status')},"verified_helper_guidance":guidance,"organisation_reply":response_text}
        r=client.responses.create(model=OPENAI_MODEL,instructions=instructions,input=json.dumps(payload,ensure_ascii=False),store=False)
        raw=(r.output_text or '').strip()
        raw=re.sub(r'^```(?:json)?\s*|\s*```$','',raw,flags=re.S)
        out=json.loads(raw)
        for k in ('answered','unanswered','evidence','review_questions'):
            if not isinstance(out.get(k),list): out[k]=[]
        out['trigger']=str(out.get('trigger') or fallback['trigger'])
        out['next_step']=str(out.get('next_step') or fallback['next_step'])
        out['warning']=str(out.get('warning') or 'AI-assisted analysis is guidance, not legal advice.')
        out['mode']='openai'
        return out
    except Exception as e:
        audit('response_analyser_fallback',None,{"error":str(e)[:300]})
        fallback['mode']='rules-fallback'
        return fallback

@app.post("/api/analyse-response")
def analyse_response(data:AnalyseResponseIn, request:Request):
    u=current_user(request,True); check_rate(request,u['id'],20)
    case=get_case_owned(u['id'],data.case_id)
    result=live_response_analysis(case,data.response_text,u.get('ai_enabled',False))
    audit('response_analysed',u['id'],{"case_id":data.case_id,"mode":result.get('mode')})
    return {"analysis":result,"category":case.get('category'),"grounded":True}

def specialist_review_rules(case: dict, documents: list[dict], extra_context: str="") -> dict:
    guidance=build_grounding(case).get("category") or {}
    facts=(case.get("facts") or "").strip()
    desired=(case.get("desired_outcome") or "").strip()
    evidence=[d.get("name") for d in documents if d.get("name")]
    evidence_guidance=(guidance.get("evidence") or [])[:6]
    specialist_signals=[]
    blob=(facts+" "+extra_context).lower()
    high_value_terms=("expert report","survey","structural","tribunal","court","pre-action","litigation","deadline","final response","deadlock","dismissal","discrimination","large repair","warranty exclusion")
    if any(t in blob for t in high_value_terms): specialist_signals.append("The saved case mentions an issue that may benefit from professional interpretation or formal escalation.")
    if len(facts)>1800: specialist_signals.append("The case contains a substantial factual history; a structured professional review may help separate the key issues from background correspondence.")
    if documents: specialist_signals.append(f"There are {len(documents)} saved document(s) to organise for any adviser. HELPER has indexed their names only; their contents are not automatically read for this review.")
    if not specialist_signals: specialist_signals.append("No single high-risk signal can be confirmed from the saved fields alone. Use the questions below to decide whether specialist input is proportionate.")
    gaps=[]
    if not documents: gaps.append("No evidence files are currently saved to this case.")
    gaps.extend([str(x) for x in evidence_guidance[:4] if str(x) not in evidence])
    questions=[str(x) for x in (guidance.get("case_review_questions") or [])[:6]]
    if not questions:
        questions=["What facts or liability points remain disputed?","Is there an urgent or uncertain deadline that needs professional checking?","Is the value or technical complexity high enough to justify specialist advice?"]
    timing=str(guidance.get("trigger_points") or "Check the current official guidance for any complaint, ombudsman, court or tribunal deadline before relying on a date.")
    next_step=str(guidance.get("next_step") or "Organise the chronology and key evidence, then decide whether a qualified specialist should review the unresolved issues.")
    summary=f"{case.get('organisation')}: {case.get('category')} case. Status: {case.get('status')}."
    if case.get('subcategory'): summary+=f" Issue: {case.get('subcategory')}."
    pack_lines=[
      "HELPER SPECIALIST REVIEW PACK — FIRST-PASS PREPARATION",
      "",
      "Case summary", summary,
      "",
      "Consumer's account", facts or "No factual summary saved.",
      "",
      "Outcome sought", desired or "Not yet recorded.",
      "",
      "Saved evidence index", *(f"- {x}" for x in evidence or ["No saved evidence files."]),
      "",
      "Why specialist input may help", *(f"- {x}" for x in specialist_signals),
      "",
      "Evidence / information to check", *(f"- {x}" for x in gaps[:8]),
      "",
      "Timing / trigger to verify", timing,
      "",
      "Questions for a specialist", *(f"- {x}" for x in questions),
      "",
      "Suggested next action", next_step,
      "",
      "Important: this is an AI/rules-assisted case-preparation document, not legal advice, a merits assessment or a prediction of outcome. Critical facts and deadlines should be checked by the appropriate official source or qualified professional."
    ]
    return {
      "executive_summary":summary,
      "case_stage":case.get("status") or "Open",
      "accepted_disputed_unanswered":["The saved case does not reliably distinguish accepted, disputed and unanswered points unless they are stated in the case summary or extra context. A professional should verify these against the correspondence."],
      "evidence_held":evidence or ["No saved evidence files indexed."],
      "evidence_gaps":gaps[:8] or ["Compare the saved evidence against HELPER's category checklist and the organisation's latest response."],
      "specialist_signals":specialist_signals,
      "issues_for_professional":["Interpret any disputed contract, policy, warranty, technical or legal point that determines responsibility or remedy.","Check proportionality, available routes and any material litigation/tribunal risk before formal proceedings."],
      "timing_to_verify":timing,
      "questions_for_specialist":questions,
      "next_action":next_step,
      "pack_text":"\n".join(pack_lines),
      "mode":"rules",
      "warning":"First-pass case preparation only — not legal advice, not a merits assessment and not a prediction of outcome. Uploaded document contents are not automatically analysed."
    }

def live_specialist_review(case: dict, documents: list[dict], extra_context: str, allow_live: bool) -> dict:
    fallback=specialist_review_rules(case,documents,extra_context)
    if not OPENAI_API_KEY or not allow_live: return fallback
    try:
        from openai import OpenAI
        client=OpenAI(api_key=OPENAI_API_KEY)
        guidance=build_grounding(case)
        payload={
          "case":{k:case.get(k) for k in ("organisation","category","subcategory","problem_date","facts","desired_outcome","status","details")},
          "saved_document_index":[{"name":d.get("name"),"content_type":d.get("content_type"),"created_at":d.get("created_at")} for d in documents],
          "extra_context_supplied_by_user":extra_context,
          "verified_helper_guidance":guidance
        }
        instructions=("You are HELPER Specialist Review, a UK consumer case-preparation assistant. Produce a cautious first-pass review that helps a consumer prepare for a solicitor, surveyor, regulated adviser or other specialist. "
          "Return valid JSON only with keys executive_summary, case_stage, accepted_disputed_unanswered, evidence_held, evidence_gaps, specialist_signals, issues_for_professional, timing_to_verify, questions_for_specialist, next_action, pack_text, warning. "
          "The six list fields accepted_disputed_unanswered, evidence_held, evidence_gaps, specialist_signals, issues_for_professional, questions_for_specialist must be arrays of concise strings. Other fields are strings. "
          "Do NOT provide a percentage chance of success, label a case strong/weak, determine legal merits, guarantee an outcome, invent admissions, infer the contents of uploaded files, or state a deadline/legal rule not present in verified HELPER guidance. "
          "Document metadata is an index only: say clearly that file contents were not automatically reviewed. Distinguish the consumer's allegation from an established fact. Identify what a human specialist should verify. "
          "If a deadline is uncertain or case-dependent, say it needs checking against the current official source or by a qualified professional. The pack_text should be a professional plain-text handover with headings: Case summary; Chronology/known facts; Outcome sought; Accepted/disputed/unanswered; Evidence index; Evidence gaps; Why specialist input may help; Timing to verify; Questions for specialist; Suggested next action; Important limitation. "
          "This is case preparation, not legal advice or regulated representation.")
        r=client.responses.create(model=OPENAI_MODEL,instructions=instructions,input=json.dumps(payload,ensure_ascii=False),store=False)
        raw=(r.output_text or "").strip()
        raw=re.sub(r'^```(?:json)?\s*|\s*```$','',raw,flags=re.S)
        out=json.loads(raw)
        for k in ("accepted_disputed_unanswered","evidence_held","evidence_gaps","specialist_signals","issues_for_professional","questions_for_specialist"):
            if not isinstance(out.get(k),list): out[k]=fallback[k]
        for k in ("executive_summary","case_stage","timing_to_verify","next_action","pack_text","warning"):
            out[k]=str(out.get(k) or fallback[k])
        out["mode"]="openai"
        return out
    except Exception as e:
        audit("specialist_review_fallback",None,{"error":str(e)[:300]})
        fallback["mode"]="rules-fallback"
        return fallback

@app.post("/api/specialist-review")
def specialist_review(data:SpecialistReviewIn, request:Request):
    u=current_user(request,True); check_rate(request,u['id'],15)
    case=get_case_owned(u['id'],data.case_id)
    con=db(); rows=con.execute("SELECT id,original_name_enc,content_type,created_at FROM documents WHERE case_id=? AND user_id=? ORDER BY id DESC",(data.case_id,u['id'])).fetchall(); con.close()
    docs=[{"id":r['id'],"name":dec(r['original_name_enc']),"content_type":r['content_type'],"created_at":r['created_at']} for r in rows]
    result=live_specialist_review(case,docs,data.extra_context,u.get('ai_enabled',False))
    audit("specialist_review",u['id'],{"case_id":data.case_id,"mode":result.get('mode'),"documents":len(docs)})
    return {"review":result,"category":case.get("category"),"grounded":True,"document_contents_analysed":False}

@app.get("/api/messages")
def messages(request:Request, case_id:Optional[int]=None):
    u=current_user(request); con=db();
    if case_id is not None: get_case_owned(u['id'],case_id); rows=con.execute("SELECT * FROM messages WHERE user_id=? AND case_id=? ORDER BY id",(u['id'],case_id)).fetchall()
    else: rows=con.execute("SELECT * FROM messages WHERE user_id=? AND case_id IS NULL ORDER BY id",(u['id'],)).fetchall()
    con.close(); return {"messages":[{"id":r['id'],"role":r['role'],"content":dec(r['content_enc']),"ai_mode":r['ai_mode'],"created_at":r['created_at']} for r in rows]}

@app.put("/api/privacy/ai-preference")
def set_ai_preference(data:AiPreferenceIn, request:Request):
    u=current_user(request,True); con=db(); con.execute("UPDATE users SET ai_enabled=?,updated_at=? WHERE id=?",(int(data.enabled),now_iso(),u['id'])); con.commit(); con.close(); audit("ai_preference",u['id'],{"enabled":data.enabled}); return {"ok":True,"ai_enabled":data.enabled,"live_ai_available":bool(OPENAI_API_KEY)}

@app.get("/api/privacy/export")
def privacy_export(request:Request):
    u=current_user(request); con=db(); user=con.execute("SELECT * FROM users WHERE id=?",(u['id'],)).fetchone(); cases=con.execute("SELECT * FROM cases WHERE user_id=?",(u['id'],)).fetchall(); msgs=con.execute("SELECT * FROM messages WHERE user_id=?",(u['id'],)).fetchall(); docs=con.execute("SELECT * FROM documents WHERE user_id=?",(u['id'],)).fetchall(); letters=con.execute("SELECT * FROM generated_letters WHERE user_id=?",(u['id'],)).fetchall(); con.close()
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
        profile={"email":user['email'],"name":dec(user['display_name_enc']),"created_at":user['created_at'],"retention_days":user['retention_days']}
        z.writestr("profile.json",json.dumps(profile,indent=2))
        z.writestr("cases.json",json.dumps([case_to_dict(r) for r in cases],indent=2))
        z.writestr("messages.json",json.dumps([{"case_id":r['case_id'],"role":r['role'],"content":dec(r['content_enc']),"ai_mode":r['ai_mode'],"created_at":r['created_at']} for r in msgs],indent=2))
        z.writestr("generated_letters.json",json.dumps([{"case_id":r['case_id'],"letter_type":r['letter_type'],"title":dec(r['title_enc']),"body":dec(r['body_enc']),"created_at":r['created_at']} for r in letters],indent=2))
        for d in docs:
            try: z.writestr(f"documents/{d['id']}_{dec(d['original_name_enc'])}",fernet.decrypt(read_blob(d['stored_key'])))
            except Exception: pass
    audit("privacy_export",u['id']); buf.seek(0); return StreamingResponse(buf,media_type="application/zip",headers={"Content-Disposition":"attachment; filename=helper-data-export.zip"})

@app.put("/api/privacy/retention")
def set_retention(data:RetentionIn, request:Request):
    u=current_user(request,True); con=db(); con.execute("UPDATE users SET retention_days=?,updated_at=? WHERE id=?",(data.retention_days,now_iso(),u['id'])); con.commit(); con.close(); audit("retention_changed",u['id'],{"days":data.retention_days}); return {"ok":True,"retention_days":data.retention_days}

@app.delete("/api/privacy/account")
def delete_account(request:Request, response:Response):
    u=current_user(request,True); con=db(); docs=con.execute("SELECT stored_key FROM documents WHERE user_id=?",(u['id'],)).fetchall();
    # Live system deletion is immediate; audit entry is non-content operational metadata.
    con.execute("DELETE FROM users WHERE id=?",(u['id'],)); con.commit(); con.close()
    for d in docs:
        try:delete_blob(d['stored_key'])
        except Exception:pass
    response.delete_cookie(SESSION_COOKIE_NAME,path="/"); audit("account_deleted",None,{"former_user_id":u['id']}); return {"ok":True,"message":"Your live Uúba account data has been deleted. Backup copies, if configured, are governed by the backup retention schedule."}

@app.post("/api/admin/retention/run")
def run_retention(request:Request):
    admin=os.getenv("HELPER_ADMIN_TOKEN","")
    supplied=request.headers.get("authorization","")
    if not admin or supplied != f"Bearer {admin}": raise HTTPException(403,"Admin token required.")
    cutoff=(datetime.now(timezone.utc)-timedelta(days=90)).isoformat(); con=db(); a=con.execute("DELETE FROM audit_log WHERE created_at<?",(cutoff,)).rowcount; r=con.execute("DELETE FROM rate_events WHERE created_ts<?",(int(time.time())-86400,)).rowcount; s=con.execute("DELETE FROM sessions WHERE expires_at<?",(now_iso(),)).rowcount
    # Delete closed/resolved cases when their owner's configured retention period has elapsed.
    expired_sql = (
        "SELECT c.id,c.user_id FROM cases c JOIN users u ON u.id=c.user_id WHERE c.closed_at IS NOT NULL AND (CURRENT_TIMESTAMP - c.closed_at::timestamptz) >= (u.retention_days * INTERVAL '1 day')"
        if is_postgres(DATABASE_URL) else
        "SELECT c.id,c.user_id FROM cases c JOIN users u ON u.id=c.user_id WHERE c.closed_at IS NOT NULL AND julianday('now')-julianday(c.closed_at) >= u.retention_days"
    )
    expired=con.execute(expired_sql).fetchall()
    removed_cases=0
    for row in expired:
        docs=con.execute("SELECT stored_key FROM documents WHERE case_id=? AND user_id=?",(row['id'],row['user_id'])).fetchall()
        con.execute("DELETE FROM cases WHERE id=?",(row['id'],)); removed_cases+=1
        for d in docs:
            try: delete_blob(d['stored_key'])
            except Exception: pass
    con.commit(); con.close(); return {"ok":True,"audit_deleted":a,"rate_events_deleted":r,"expired_sessions_deleted":s,"expired_cases_deleted":removed_cases}

def _community_public_row(row):
    return {
      "id": row["id"], "alias": dec(row["alias_enc"]), "category": row["category"],
      "organisation": dec(row["organisation_enc"]), "title": dec(row["title_enc"]),
      "story": dec(row["story_enc"]), "tried": dec(row["tried_enc"]),
      "helped": dec(row["helped_enc"]), "outcome": dec(row["outcome_enc"]),
      "case_status": row["case_status"], "published_at": row["published_at"]
    }

@app.get("/api/community/posts")
def community_posts(category: str = "", status: str = "", limit: int = 30):
    limit=max(1,min(limit,100)); con=db()
    sql="SELECT * FROM community_posts WHERE moderation_status='approved'"; args=[]
    if category:
        sql += " AND category=?"; args.append(category)
    if status:
        sql += " AND case_status=?"; args.append(status)
    sql += " ORDER BY COALESCE(published_at,created_at) DESC LIMIT ?"; args.append(limit)
    rows=con.execute(sql,args).fetchall(); con.close()
    return {"posts":[_community_public_row(r) for r in rows]}

@app.post("/api/community/posts")
def submit_community_post(data: CommunityPostIn, request: Request):
    u=current_user(request,True); check_rate(request,u['id'],limit=8)
    if not data.consent_publication: raise HTTPException(400,"Please confirm that you want this submission reviewed for public publication.")
    allowed_status={"Ongoing","Resolved","Escalated"}
    if data.case_status not in allowed_status: raise HTTPException(400,"Invalid case status.")
    categories=set(KNOWLEDGE.get("categories",{}).keys())
    if data.category not in categories: raise HTTPException(400,"Choose a HELPER category.")
    now=now_iso(); con=db(); cur=con.execute("INSERT INTO community_posts(user_id,alias_enc,category,organisation_enc,title_enc,story_enc,tried_enc,helped_enc,outcome_enc,case_status,moderation_status,consent_publication,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
      (u['id'],enc(data.alias.strip()),data.category,enc(data.organisation.strip()),enc(data.title.strip()),enc(data.story.strip()),enc(data.tried.strip()),enc(data.helped.strip()),enc(data.outcome.strip()),data.case_status,'pending',1,now,now))
    post_id=cur.lastrowid; con.commit(); con.close(); audit("community_post_submitted",u['id'],{"post_id":post_id,"category":data.category})
    return {"ok":True,"id":post_id,"status":"pending","message":"Thanks. Your experience has been submitted for moderation and is not public yet."}

@app.get("/api/community/mine")
def my_community_posts(request: Request):
    u=require_user(request); con=db(); rows=con.execute("SELECT * FROM community_posts WHERE user_id=? ORDER BY created_at DESC",(u['id'],)).fetchall(); con.close()
    return {"posts":[{"id":r['id'],"title":dec(r['title_enc']),"category":r['category'],"case_status":r['case_status'],"moderation_status":r['moderation_status'],"created_at":r['created_at']} for r in rows]}

@app.delete("/api/community/posts/{post_id}")
def withdraw_community_post(post_id:int, request:Request):
    u=current_user(request,True); con=db(); row=con.execute("SELECT id FROM community_posts WHERE id=? AND user_id=?",(post_id,u['id'])).fetchone()
    if not row: con.close(); raise HTTPException(404,"Submission not found.")
    con.execute("DELETE FROM community_posts WHERE id=?",(post_id,)); con.commit(); con.close(); audit("community_post_withdrawn",u['id'],{"post_id":post_id}); return {"ok":True}

@app.post("/api/community/posts/{post_id}/report")
def report_community_post(post_id:int, data:CommunityReportIn, request:Request):
    u=current_user(request,True); check_rate(request,u['id'],limit=12); con=db(); row=con.execute("SELECT id FROM community_posts WHERE id=? AND moderation_status='approved'",(post_id,)).fetchone()
    if not row: con.close(); raise HTTPException(404,"Post not found.")
    con.execute("INSERT INTO community_reports(post_id,reporter_user_id,reason,details_enc,created_at) VALUES(?,?,?,?,?)",(post_id,u['id'],data.reason.strip(),enc(data.details.strip()),now_iso())); con.commit(); con.close(); audit("community_post_reported",u['id'],{"post_id":post_id,"reason":data.reason[:80]}); return {"ok":True,"message":"Thank you. Uúba will review this post."}

def _require_admin(request:Request):
    supplied=request.headers.get("authorization","")
    if not HELPER_ADMIN_TOKEN or supplied != f"Bearer {HELPER_ADMIN_TOKEN}": raise HTTPException(403,"Admin token required.")

@app.get("/api/admin/community/pending")
def admin_community_pending(request:Request):
    _require_admin(request); con=db(); rows=con.execute("SELECT * FROM community_posts WHERE moderation_status='pending' ORDER BY created_at ASC LIMIT 200").fetchall(); con.close()
    return {"posts":[dict(_community_public_row(r), moderation_status=r['moderation_status'], created_at=r['created_at']) for r in rows]}

@app.post("/api/admin/community/posts/{post_id}/moderate")
def admin_moderate_community(post_id:int, data:CommunityModerationIn, request:Request):
    _require_admin(request); con=db(); row=con.execute("SELECT id,user_id FROM community_posts WHERE id=?",(post_id,)).fetchone()
    if not row: con.close(); raise HTTPException(404,"Post not found.")
    new_status='approved' if data.action=='approve' else 'rejected'; published=now_iso() if new_status=='approved' else None
    con.execute("UPDATE community_posts SET moderation_status=?,moderation_note_enc=?,published_at=?,updated_at=? WHERE id=?",(new_status,enc(data.note.strip()),published,now_iso(),post_id)); con.commit(); con.close(); audit("community_post_moderated",None,{"post_id":post_id,"status":new_status}); return {"ok":True,"status":new_status}

@app.get("/api/admin/community/summary")
def admin_community_summary(request:Request):
    _require_admin(request); con=db()
    counts={r['moderation_status']:r['n'] for r in con.execute("SELECT moderation_status,COUNT(*) n FROM community_posts GROUP BY moderation_status").fetchall()}
    open_reports=con.execute("SELECT COUNT(*) n FROM community_reports WHERE resolved_at IS NULL").fetchone()['n']
    total=con.execute("SELECT COUNT(*) n FROM community_posts").fetchone()['n']; con.close()
    return {"total":total,"pending":counts.get('pending',0),"approved":counts.get('approved',0),"rejected":counts.get('rejected',0),"open_reports":open_reports}

@app.get("/api/admin/community/recent")
def admin_community_recent(request:Request, limit:int=60):
    _require_admin(request); limit=max(1,min(limit,200)); con=db(); rows=con.execute("SELECT * FROM community_posts ORDER BY updated_at DESC LIMIT ?",(limit,)).fetchall(); con.close()
    return {"posts":[dict(_community_public_row(r),moderation_status=r['moderation_status'],created_at=r['created_at'],updated_at=r['updated_at'],moderation_note=dec(r['moderation_note_enc'])) for r in rows]}

@app.get("/api/admin/community/reports")
def admin_community_reports(request:Request):
    _require_admin(request); con=db(); rows=con.execute("""SELECT r.*,p.alias_enc,p.category,p.organisation_enc,p.title_enc,p.story_enc,p.tried_enc,p.helped_enc,p.outcome_enc,p.case_status,p.moderation_status,p.published_at FROM community_reports r JOIN community_posts p ON p.id=r.post_id WHERE r.resolved_at IS NULL ORDER BY r.created_at ASC LIMIT 200""").fetchall(); con.close()
    return {"reports":[{"id":r['id'],"post_id":r['post_id'],"reason":r['reason'],"details":dec(r['details_enc']),"created_at":r['created_at'],"post":{"id":r['post_id'],"alias":dec(r['alias_enc']),"category":r['category'],"organisation":dec(r['organisation_enc']),"title":dec(r['title_enc']),"story":dec(r['story_enc']),"tried":dec(r['tried_enc']),"helped":dec(r['helped_enc']),"outcome":dec(r['outcome_enc']),"case_status":r['case_status'],"moderation_status":r['moderation_status'],"published_at":r['published_at']}} for r in rows]}

@app.post("/api/admin/community/reports/{report_id}/resolve")
def admin_resolve_community_report(report_id:int, data:CommunityReportResolutionIn, request:Request):
    _require_admin(request); con=db(); row=con.execute("SELECT id,post_id FROM community_reports WHERE id=? AND resolved_at IS NULL",(report_id,)).fetchone()
    if not row: con.close(); raise HTTPException(404,"Open report not found.")
    if data.action=='unpublish':
        con.execute("UPDATE community_posts SET moderation_status='pending',moderation_note_enc=?,published_at=NULL,updated_at=? WHERE id=?",(enc(data.note.strip()),now_iso(),row['post_id']))
    elif data.action=='reject':
        con.execute("UPDATE community_posts SET moderation_status='rejected',moderation_note_enc=?,published_at=NULL,updated_at=? WHERE id=?",(enc(data.note.strip()),now_iso(),row['post_id']))
    con.execute("UPDATE community_reports SET resolved_at=? WHERE id=?",(now_iso(),report_id)); con.commit(); con.close(); audit("community_report_resolved",None,{"report_id":report_id,"post_id":row['post_id'],"action":data.action}); return {"ok":True,"action":data.action}

@app.get("/api/knowledge")
def knowledge(): return {"reviewed":KNOWLEDGE.get("reviewed"),"categories":list(KNOWLEDGE.get("categories",{}).keys())}

