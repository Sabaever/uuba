# HELPER production deployment checklist

## Required external configuration
1. HTTPS domain and reverse proxy/load balancer.
2. `HELPER_ENCRYPTION_KEY` stored in a managed secrets service, not a file.
3. `OPENAI_API_KEY` if live Ask HELPER AI is required.
4. `S3_BUCKET` (or compatible managed object storage) for encrypted document storage.
5. Managed relational database for multi-instance production deployment (the packaged app currently uses encrypted-field SQLite for its tested single-server mode).
6. SMTP/email provider for verification, password reset and service notifications.
7. Central monitoring and alerting.

## Launch gates
- Privacy notice reviewed against actual processing.
- DPIA completed where required.
- Consumer-rights knowledge reviewed by qualified subject-matter owners.
- Backup restore tested.
- Vulnerability and penetration testing complete.
- Incident-response contacts and breach process documented.
- Data subject request process tested end-to-end.
- Retention job scheduled.
- AI quality/safety test suite run across each complaint category.

## Case-generated document checks
- [ ] Have a solicitor/subject-matter reviewer review every document family before public launch.
- [ ] Confirm that generated deadlines are user-supplied or rules-derived and never invented by the AI.
- [ ] Add branded PDF/DOCX export if required for launch; current build supports print/save-PDF and text download.
- [ ] Add versioning/review dates to approved wording and source material.
- [ ] Decide whether users can send documents from HELPER; current build intentionally generates only and never sends automatically.
