# Uúba go-live checklist

## Infrastructure
- [ ] Private Git repository created.
- [ ] Render Blueprint synced successfully.
- [ ] `uuba-web` healthy.
- [ ] `uuba-postgres` healthy.
- [ ] `/api/health` reports `database: postgresql`.
- [ ] Persistent disk or private S3 storage tested.
- [ ] Restore/backup procedure tested.

## Secrets
- [ ] `UUBA_ENCRYPTION_KEY` stored securely in at least one controlled backup location.
- [ ] `UUBA_ADMIN_TOKEN` configured and moderator dashboard tested.
- [ ] `BETA_ACCESS_CODE` configured for private beta.
- [ ] OpenAI key belongs to the business account if live AI is enabled.
- [ ] No `.env`, API key, database credential or encryption key committed to Git.

## Domain
- [ ] `uuba.co.uk` added to Render.
- [ ] Wix DNS updated from the values shown by Render.
- [ ] `uuba.co.uk` loads over HTTPS.
- [ ] `www.uuba.co.uk` redirects correctly.
- [ ] No conflicting AAAA/parking/forwarding records remain.

## Product
- [ ] New Uúba 3D star/space hero is visible.
- [ ] Full 14-tab navigation works.
- [ ] Core price is Free.
- [ ] Plus price is £6.99/month or £59/year.
- [ ] Specialist Review + Pack is £24.99 one-off.
- [ ] Account creation/login/logout tested.
- [ ] Case CRUD tested.
- [ ] Documents upload/download/delete tested.
- [ ] Letters tested.
- [ ] Response Analyser tested.
- [ ] Ask Uúba rules fallback tested.
- [ ] Ask Uúba live AI opt-in tested if enabled.
- [ ] Data export tested.
- [ ] Account deletion tested on a disposable test user.
- [ ] Retention setting tested.
- [ ] Consumer Voices moderation tested.

## Legal / operations
- [ ] Company incorporated.
- [ ] Company number/address inserted into legal pages.
- [ ] `support@uuba.co.uk` monitored.
- [ ] `privacy@uuba.co.uk` monitored.
- [ ] Refund/complaint owner named internally.
- [ ] ICO fee assessment completed.
- [ ] DPIA finalised for production providers.
- [ ] Regulatory solicitor review completed before paid public launch.
- [ ] Specialist partner wording still says TBC until actual agreements exist.

## Beta
- [ ] 3–5 internal end-to-end tests passed.
- [ ] Error/log monitoring reviewed after deployment.
- [ ] First 25–50 users invited only after the checks above pass.
