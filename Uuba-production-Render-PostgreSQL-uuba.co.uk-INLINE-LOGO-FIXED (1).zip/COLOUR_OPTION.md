# Option B — Navy + Teal / Sky

Calmer, more supportive treatment. Keeps blue trust cues while using teal to distinguish analysis and guidance actions.
