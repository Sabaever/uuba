# HELPER v7 preservation audit

UÚBA is a rebrand/layer on top of HELPER v7. The original HELPER v7 archive remains the source of truth for functionality.

Checks performed before this release:
- Original file inventory compared with UÚBA.
- Legacy HELPER logo/mark files restored to the package for archival completeness.
- Original homepage section IDs checked against UÚBA.
- Original JavaScript function names checked against UÚBA.
- Original frontend API endpoint references checked against UÚBA.
- Backend route inventory preserved.
- Full 14-item navigation preserved.

No original functional section, API call or backend route should be removed by the colour/legal pass.
