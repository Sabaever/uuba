# HELPER Data Protection Impact Assessment — draft for legal review

## Processing
HELPER stores consumer complaint/dispute cases, evidence, generated correspondence and optional AI-assisted questions. Cases may contain financial, employment, property, health or allegation-related information.

## Necessity and proportionality
- Private by default.
- Minimise mandatory fields.
- Uploaded documents are encrypted before storage.
- Per-user access controls.
- AI is opt-in and receives minimised case context; uploaded evidence is not sent automatically.
- Users can export, delete and configure retention.

## Main risks
1. Account compromise exposing complaint evidence.
2. Excess collection of third-party or special-category data.
3. AI producing incorrect legal/procedural guidance.
4. Sending unnecessary identifiers to an AI processor.
5. Data retained longer than necessary.
6. Incorrect sponsorship/referral design influencing guidance.
7. Cloud/service-provider compromise.
8. Users relying on HELPER for urgent limitation deadlines.

## Controls
- Argon2 password hashing, secure sessions, CSRF, rate limiting, HTTPS in production.
- Encryption of sensitive database fields and documents.
- Ownership checks for all case/document access.
- Verified-rule grounding and official-source links.
- AI opt-in and `store=false`; minimise prompt data.
- Clear “not a law firm / no guaranteed outcome” notices.
- Retention scheduler and account deletion/export.
- Sponsored content clearly labelled and separated from guidance/ranking.
- Incident response and backup controls.

## Residual risks requiring sign-off before public launch
- Legal basis/Article 9 condition for any special-category processing must be formally documented.
- International transfer assessments for each processor.
- Review of regulated claims-management boundaries.
- Review of solicitor sponsorship/referral model.
- External penetration/security testing.
- Legal review of user-facing wording.

## Consultation/sign-off
Owner: [NAME]
Data protection reviewer: [NAME/ADVISER]
Legal reviewer: [SOLICITOR]
Date approved: [DATE]
Review date: [DATE]
