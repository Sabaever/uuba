# HELPER Record of Processing Activities — working draft

| Activity | Data subjects | Data | Purpose | Lawful basis | Processors | Retention |
|---|---|---|---|---|---|---|
| Account management | Users | email, name, password hash, security metadata | provide secure account | contract / legitimate interests | hosting provider | account lifetime + defined security periods |
| Case management | Users and persons mentioned in complaints | case facts, refs, correspondence metadata | provide HELPER case service | contract; Article 9 basis to be documented where special-category data occurs | hosting/database/storage | case retention setting |
| Evidence storage | Users and third parties in evidence | uploaded files | organise case evidence | contract; additional conditions where required | encrypted object storage | case retention setting |
| Ask HELPER rules mode | Users | question, case context | guidance | contract | HELPER hosting | case/account retention |
| Ask HELPER live AI | Users | minimised question + case context | AI explanation/drafting | contract / consent/choice for AI feature; final legal analysis required | OpenAI API | HELPER retention + provider controls |
| Security/audit | Users | IP/user-agent hashes, events | security, fraud prevention | legitimate interests | hosting/security providers | short security schedule |
| Marketing | opted-in users | email/preferences | optional updates | consent | email provider | until withdrawal |
