# Uúba production deployment — Render + PostgreSQL + uuba.co.uk

This package is prepared for a **private-beta production deployment** on Render.

## 1. Put this folder in a private Git repository

Render Blueprints deploy from a Git repository. Keep the repository private and do not commit real secrets or the prototype SQLite database.

The included `.gitignore` / `.dockerignore` exclude the development DB, encryption key, uploads and backups.

## 2. Generate production secrets

Run locally:

```bash
python generate_secrets.py
```

Copy the three values somewhere secure. You will enter them in Render when the Blueprint asks for secrets.

**Important:** never change `UUBA_ENCRYPTION_KEY` after real encrypted case data exists unless you deliberately re-encrypt that data. Losing it makes encrypted fields unreadable.

## 3. Create the Render Blueprint

In Render:

1. **New → Blueprint**.
2. Connect the private repository containing this package.
3. Render reads `render.yaml` and creates:
   - `uuba-web` — Docker web service in Frankfurt.
   - `uuba-postgres` — PostgreSQL in Frankfurt.
4. The database is linked to the app through `DATABASE_URL` using Render's managed PostgreSQL connection pool.
5. Enter all `sync: false` secrets when prompted.

Required for first production deploy:

- `UUBA_ENCRYPTION_KEY`
- `UUBA_ADMIN_TOKEN`
- `BETA_ACCESS_CODE` — keep this set for the private beta. Remove it only when you intentionally open registration publicly.

Optional until live AI is enabled:

- `OPENAI_API_KEY`
- `OPENAI_MODEL`

Optional object storage:

- `S3_BUCKET`
- `AWS_ACCESS_KEY_ID`
- `AWS_SECRET_ACCESS_KEY`

If S3 is not configured, evidence files remain Fernet-encrypted and are stored on the attached Render persistent disk at `/app/data`.

## 4. PostgreSQL

Production refuses to start without a PostgreSQL `DATABASE_URL`. The app still supports SQLite for local development only.

The database schema is created automatically on startup.

### Migrating existing prototype data

If the existing SQLite database contains real beta cases you want to keep:

```bash
export DATABASE_URL='postgresql://...'
python migrate_sqlite_to_postgres.py --sqlite data/helper.db
```

Use the **same encryption key** that was used to encrypt the SQLite data. If the current database only contains development/test data, start with the clean PostgreSQL database instead.

## 5. Connect uuba.co.uk

The Blueprint declares `uuba.co.uk` as the production domain.

After the Render web service exists:

1. Open **uuba-web → Settings → Custom Domains** and confirm `uuba.co.uk` is present.
2. In the Wix DNS manager for `uuba.co.uk`, remove conflicting forwarding/parking records.
3. Follow the DNS values shown by Render. For a normal DNS provider, Render currently documents:
   - root `@`: **A** record → `216.24.57.1`
   - `www`: **CNAME** → your Render service hostname (for example `uuba-web.onrender.com`)
4. Remove conflicting `AAAA` records while configuring the domain.
5. Return to Render and click **Verify**.

Render automatically provisions TLS/HTTPS for verified custom domains and redirects HTTP to HTTPS. A root custom domain also gets a matching `www` redirect arrangement.

Do not guess DNS values if the Render dashboard shows different values — use the values shown for the actual service.

## 6. Production security settings already applied

The package now:

- requires PostgreSQL in `production`;
- requires `COOKIE_SECURE=1`;
- requires a persistent `UUBA_ENCRYPTION_KEY`;
- uses the `uuba_session` cookie name;
- applies trusted-host validation;
- adds HSTS in production;
- adds `X-Content-Type-Options`, `X-Frame-Options`, Referrer Policy and a restrictive Permissions Policy;
- hashes session tokens and selected request fingerprint data;
- encrypts case content/evidence before storage;
- keeps AI opt-in separate and uses the rules fallback when no AI key is configured.

## 7. Email before inviting beta users

Configure at least:

- `hello@uuba.co.uk`
- `support@uuba.co.uk`
- `privacy@uuba.co.uk`

Replace the remaining square-bracket placeholders in the legal pages before public launch.

## 8. Health check

After deployment open:

`https://uuba.co.uk/api/health`

Expected production fields include:

```json
{
  "ok": true,
  "environment": "production",
  "database": "postgresql"
}
```

Check that `storage` is either `s3` or `encrypted-local` (persistent disk).

## 9. Do not launch paid public subscriptions yet

The website retains the agreed pricing:

- **Core — Free**
- **Plus — £6.99/month or £59/year**
- **AI Specialist Review + Pack — £24.99 one-off**

Payment processing is intentionally not invented in this package. Add the real payment provider only after company details, subscription/cancellation flows, refunds and final legal review are settled.

## 10. Private-beta go-live order

1. Deploy Blueprint.
2. Confirm PostgreSQL health.
3. Confirm encryption/admin/beta secrets.
4. Test account registration/login/logout.
5. Test case create/edit/delete.
6. Upload/download/delete a test document.
7. Test Ask Uúba with AI disabled.
8. If using AI, add company-owned OpenAI credentials and test opt-in.
9. Test Response Analyser and generated letters.
10. Test export/delete/retention controls.
11. Test Consumer Voices submission, reporting and moderation.
12. Test all 14 navigation tabs, prices and legal links on desktop/mobile.
13. Connect and verify `uuba.co.uk`.
14. Invite the first 25–50 private-beta users.
