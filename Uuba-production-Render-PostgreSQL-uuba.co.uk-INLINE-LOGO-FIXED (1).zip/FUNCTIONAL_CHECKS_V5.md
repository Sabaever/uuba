# HELPER v5 functional checks

- My Rights cards now link to detailed category guidance and a 10-category rights route grid.
- Ask HELPER and Response Analyser show live server AI status.
- Actual outputs already label `Live AI` vs `Verified rules fallback`.
- Consumer Voices Full Community is embedded directly in the main index.
- Share your experience form is embedded directly in the main index.
- Static-file preview shows explanatory content rather than blank navigation.
- Live community submissions/feed require the FastAPI server, sign-in for submission, and moderation before publication.
