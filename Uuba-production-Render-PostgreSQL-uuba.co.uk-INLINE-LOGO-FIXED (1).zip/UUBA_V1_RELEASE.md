# UÚBA v1 — Rebrand of HELPER v7

This release is rebuilt directly from the untouched HELPER v7 package to preserve the complete existing product navigation and functionality.

## Preserved original navigation
Why UÚBA · Start a case · My cases · Ask UÚBA · Analyse a reply · My rights · Detailed guidance · Specialist help · Consumer Voices · Create a letter · Template library · Plans · How it works · Privacy

## Brand integration
- Final UÚBA wordmark in the main header
- UÚBA wordmark and guidance panel in the homepage hero
- UÚBA favicon/app mark
- Final wordmark in footer and secondary page headers
- Star/path guidance brand story
- Primary domain: https://uuba.co.uk/

Legacy internal HELPER identifiers remain where necessary for application compatibility.
