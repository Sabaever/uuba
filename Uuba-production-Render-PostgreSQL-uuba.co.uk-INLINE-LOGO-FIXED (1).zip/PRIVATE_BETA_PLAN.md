# HELPER Controlled Private Beta Plan

## Proposed cohort
25–50 invited UK users across a limited set of complaint types. Avoid recruiting users with urgent court/tribunal deadlines in the first cohort unless a qualified adviser is involved.

## Entry controls
- Invitation/access code.
- Account verification process to be added before wider release.
- Explicit acceptance of Terms and Privacy Notice.
- AI processing opt-in separate from account terms.

## Success measures
- User can identify the correct category and next step.
- User can save a case and evidence without assistance.
- Ask HELPER gives a useful grounded answer.
- Generated letter accurately reflects saved facts.
- User understands trigger points and escalation body.
- No material privacy/security incidents.

## Human review loop
Sample beta outputs weekly for accuracy, with personal data minimised. Log incorrect or unsafe guidance as product defects and update the verified rules store.

## Stop conditions
Pause beta if there is a material data breach, repeated incorrect deadline advice, uncontrolled AI hallucination, inability to restore backups, or evidence that the service is crossing a regulated-claims boundary without authorisation.
