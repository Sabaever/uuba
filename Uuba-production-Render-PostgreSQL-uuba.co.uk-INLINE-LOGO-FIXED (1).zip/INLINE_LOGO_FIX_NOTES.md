This build embeds the Uúba logo directly into the HTML as a data URI on the main pages so it cannot break due to missing relative asset paths when opened locally.
